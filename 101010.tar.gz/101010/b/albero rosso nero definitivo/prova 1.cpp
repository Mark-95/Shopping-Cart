#include<iostream>
#include<ctime>
#include<math.h>
using namespace std;
template <class T> class Nodo{
	public:
		T valore;
		Nodo<T>* right, *left, *parent;
		int color;
		Nodo<T>(T x){
			valore=x;
			right=left=parent=NULL;
		}	
};

template <class T> class Albero{
	public:
		Nodo<T>* radice;
		Albero<T>(){
			radice=NULL;
		}
		
                
		Albero<T>* insert(T x){
			Nodo<T>* nuovo= new Nodo<T>(x);            //Creiamo un nuovo nodo
			Nodo<T>* temp=radice;                      //puntatore inizializzato alla radice
			Nodo<T>* y=NULL;                           //puntatore predecessore NULL
			while(temp!=NULL){                         //scorro l'albero fino a quando temp!=NULL
			    y=temp;
			    if(temp->valore<x) temp=temp->right;   //se il valore da inserire 'x' è > del valore del corrente nodo vado a destra
			    else temp=temp->left;                  //Altrimenti vado a sinistra  
			}
			nuovo->parent=y;                           //il padre del nuovo nodo sarà 'y'
			if(y==NULL) radice=nuovo;                  //se 'y' è NULL e dunque se il padre del nuovo nodo è NULL allora nuovo=radice
			else if(y->valore<x) y->right=nuovo;       //se il valore da inserire 'x' è > del valore del nodo padre allora 'nuovo' sarà figlio destro 
			else y->left=nuovo;                        //Altrimenti se il valore da inserire 'x' è < del valore del nodo padre allora 'nuovo' sarà figlio sinistro 
			return this;
		}
		

                //Parto dalla radice e scorro l'albero fino a quando temp!=NULL
                //e vado a destra se il valore da cercare 'x' è maggiore del valore del corrente nodo
                //Altrimenti vado a sinistra se il valore da cercare 'x' è minore del valore del corrente nodo
                //Se quando esco dal ciclo, temp!=NULL allora ho trovato il valore e restituisco il puntatore temp,
                //Altrimenti il valore non è stato trovato e restiuisco NULL.
		Nodo<T>* search(T x){
			Nodo<T>* temp=radice;
			while(temp!=NULL && temp->valore!=x){
				if(temp->valore<x) temp=temp->right;
				else temp=temp->left;
			}
			if(temp!=NULL) return temp;
			else return NULL;
		}
		
		Albero<T>* rightRotate(Nodo<T>* y){
			Nodo<T>* x=y->left;
			Nodo<T>* z=y->parent;
			y->left=x->right;
			x->right=y;
			if(z!=NULL){
				if(y==z->right) z->right=x;
				else z->left=x;
			}
			else radice=x;
			x->parent=z;
			y->parent=x;
			if(y->left!=NULL) y->left->parent=y;
			return this;
		}
		
		Albero<T>* leftRotate(Nodo<T>* y){
			Nodo<T>* x=y->right;                 //x= figlio destro di 'y'
			Nodo<T>* z=y->parent;                //z= padre di 'y'
			y->right=x->left;                    //puntatore destro di 'y' punta al figlio sinistro di 'x'
			x->left=y;                           //puntatore sinistro di 'x' punta a 'y'
			if(z!=NULL){                         //se il padre di 'y' cioè 'z' esiste
				if(y==z->right) z->right=x;  //allora se 'y' è figlio destro di 'z' allora il puntatore destro di 'z' punta a 'x' 
				else z->left=x;              //altrimenti il puntatore sinistro di 'z' punta a 'x'
			}
			else radice=x;                       //se invece il padre non esiste allora 'x' diventa radice
			x->parent=z;                         //il padre di 'x' è 'z' ovvero quello che prima era padre di 'y'
			y->parent=x;                         //padre di 'y' è 'x' ovverro quello che prima era il figlio destro di 'y'
			if(y->right!=NULL) y->right->parent=y;  //se il figlio destro esiste allora suo padre sarà 'y'
			return this;
		}
		

                //il minimo di un sottoalbero lo si ottiene scorrendo tutti i figli sinistri del sottoalbero, 
                //se il nodo 'n' è NULL allora non esiste minimo quindi restituiamo NULL
		Nodo<T>* minimo(Nodo<T>* n){
			if(n==NULL) return n;
			Nodo<T>* temp=n;
			while(temp->left!=NULL) temp=temp->left;
			return temp;
		}
		
	        //il massimo di un sottoalbero lo si ottiene scorrendo tutti i figli destri del sottoalbero, 
                //se il nodo 'n' è NULL allora non esiste massimo quindi restituiamo NULL
		Nodo<T>* massimo(Nodo<T>* n){
			if(n==NULL) return n;
			Nodo<T>* temp=n;
			while(temp->right!=NULL) temp=temp->right;
			return temp;
		}
		

	        //valore massimo del sottoalbero sinistro del nodo 'n'
                //se il nodo 'n' non ha sottoalbero sinistro allora bisogna cercare negli antenati di 'n'
                //ed in particolar modo saliamo di padre in padre fino a quando il figlio proviene da sinistra,
                //cioè se il nodo corrente 'n' sta alla destra del suo antenato allora quest'ultimo antenato è il predecessore.
		Nodo<T>* predecessore(Nodo<T>* n){
			if(n==NULL) return;
			if(n->left!=NULL) return massimo(n->left);
			Nodo<T>* temp=n->parent;
			while(temp!=NULL && n==temp->left){
				n=temp;
				temp=temp->parent;
			}
			return temp;
		}
		
                //valore minimo del sottoalbero destro del nodo 'n'
                //se il nodo 'n' non ha sottoalbero destro allora bisogna cercare negli antenati di 'n'
                //ed in particolar modo saliamo di padre in padre fino a quando il figlio proviene da destra,
                //cioè se il nodo corrente 'n' sta alla sinistra del suo antenato allora quest'ultimo antenato è il successore.
		Nodo<T>* successore(Nodo<T>* n){
			if(n==NULL) return;
			if(n->right!=NULL) return minimo(n->right);
			Nodo<T>* temp=n->parent;
			while(temp!=NULL && n==temp->right){
				n=temp;
				temp=temp->parent;
			}
			return temp;
		}
		
		Nodo<T>* delete_node(T key){
			Nodo<T>* n=search(key);
			if(!n) return NULL;             //se n==NULL
			Nodo<T>* p=n->parent;
			if(n->left==NULL){
				if(p){                                      //se p!=NULL
					if(n==p->left) p->left=n->right;
					else p->right=n->right;
				}
				else radice=n->right;
				if(n->right) n->right->parent=p;
				return n;
			}
			
			if(n->right==NULL){
				if(p){
					if(n==p->left) p->left=n->left;
					else p->right=n->left;
				}
				else radice=n->left;
				if(n->left) n->left->parent=p;      //Se n->left!=NULL allora aggiorna suo padre con il nonno cioè il padre di 'n'
				return n;
			}
			
			Nodo<T>* s=successore(n);
			del(s->valore);
			n->valore=s->valore;
			return s;
		}
		
		Albero<T>* del(T key){
			delete_node(key);
			return this;
		}
		
		Albero<T>* rightRotate(T key){
			Nodo<T>* n=search(key);
			if(n!=NULL) rightRotate(n);
			return this;
		}
		
		Albero<T>* leftRotate(T key){
			Nodo<T>* n=search(key);
			if(n!=NULL) leftRotate(n);
			return this;
		}
		
};
