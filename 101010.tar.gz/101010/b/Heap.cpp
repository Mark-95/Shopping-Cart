#include <iostream>
#include <ctime>
#include <math.h>
using namespace std;


template <class T> class PriorityQueue {
	public:
		virtual T* extract() = 0;
		virtual PriorityQueue<T>* enqueue(T x) = 0;
		virtual int size() = 0;
};

template <class H> class BinaryHeap : public PriorityQueue<H>{
        
        //Variabili e metodi privati
	private:
		H **A;
		int heapsize;                                     //Dimensione Heap
		int len;                                          //Dimensione array A
		int left(int i) { return i<<1; }                  //eseguo lo shift di 1 bit sul nodo di indice 'i'  da destra verso sinistra in modo da ottenere il doppio di 'i' e quindi nodo left
		int right(int i) { return (i<<1)|1; }             //eseguo lo shift di 1 bit sul nodo di indice 'i'  da destra verso sinistra in modo da ottenere il doppio di 'i' +1 e quindi nodo right
		int parent(int i) { return i>>1; }                //eseguo lo shift di 1 bit sul nodo di indice 'i'  da sinistra verso destra in modo da ottenere la metà di  'i'  e quindi il padre
		
                //Scambia i valori del nodo 'i' e del nodo 'j'
		void scambia(int i, int j) {              
			H* tmp = A[i];               //tmp è un puntatore di tipo 'H' che punta al puntatore contenuto nel cassetto A[i] che è di tipo 'H'
			A[i] = A[j];                 //inserisco il puntatore presente nel cassetto A[j] in A[i]
			A[j] = tmp;                  //ed infine copio il ciò che punta tmp in A[j]
		}
		
                //Metodo che permette di mantenere la proprietà Heap
		void heapify(int i) {
			if(i>heapsize) return;  			//se l'indice passato è maggiore della dimensione dell'heap interrompi l'esecuzione
			int l = left(i);                                //nodo sinistro di 'i'
			int r = right(i);                               //nodo destro di 'i'
			int v = i;                                      //'v' equivale 'smaller' ovvero contiene l'indice del nodo la cui chiave è minore e la inizializziamo all'indice passato cioè 'i'
			if(l<=heapsize && compare(A[v], A[l])<0) v=l;   //Se il nodo sinistro fa parte del Heap & A[v] > A[l]  allora aggiorniamo 'v' con il nuovo valore più piccolo cioè v=l
			if(r<=heapsize && compare(A[v], A[r])<0) v=r;   //Se il nodo destro fa parte del Heap & A[v] > A[r]  allora aggiorniamo 'v' con il nuovo valore più piccolo cioè v=l
			if(v==i) return;                                //Se l'indice 'i' è lo stesso di 'v' significa che 'v' rappresentava il nodo più piccolo e quindi interrompo l'esecuzione
			scambia(i,v);                                   //Altrimenti procedo scambiando i valori del nodo 'i' e nodo 'v'  attraverso l'esecuzione del metodo scambia()
			heapify(v);                                     //Eseguo una chiamata ricorsiva ad heapify() in modo da cercare un nuovo minimo se esiste a partire dal valore più piccolo appena trovato
		}
		
	
	//Variabili e metodi pubblici	
	public:
		virtual int compare(H *a, H *b)=0;
		BinaryHeap(int size) {
			A = new H*[size];
			len = size;
			heapsize = 0;
		}

		BinaryHeap(H** V, int size) {
			A = V;
			len = size+1;
			heapsize = size;
		}
		
		void buildHeap() {
			for(int i=heapsize/2; i>0; i--)
				heapify(i);
		}

		H* extract() {
			if(heapsize==0) return NULL;
			scambia(1, heapsize);
			heapsize--;
			heapify(1);
			return A[heapsize+1];
		}

		void modify(int i, H k) {
			if(i<1 || i>heapsize) return;
			if( compare(A[i],&k)>=0 ) return;
			A[i] = new H(k);
			while(i>1 && compare(A[i],A[parent(i)])>0) {
				scambia(i,parent(i));
				i = parent(i);
			}
			return;
		}
		
		BinaryHeap<H>* enqueue(H x) {
			if(heapsize==len-1) return this;
			heapsize += 1;
			A[heapsize] = new H(x);
			int i = heapsize;
			while(i>1 && compare(A[i],A[parent(i)])>0) {
				scambia(i, parent(i));
				i = parent(i);
			}
			return this;
		}
		
		void sort() {
			buildHeap();
			int n = heapsize;
			for(int i=0; i<n; i++) extract();
			heapsize = n;
		}
						
		int size() {
			return heapsize;
		}
		
		void print() {
			for(int i=1; i<=heapsize; i++) 
				cout << *A[i] << " ";
			cout << endl;
		}
};


template <class H> class MinBinaryHeap : public BinaryHeap<H> {
	private: 
	public:
		int compare(H* a, H *b) {
			return (*b)-(*a);
		}
		MinBinaryHeap(int size) : BinaryHeap<H>(size) {}
		MinBinaryHeap(H **A, int size) : BinaryHeap<H>(A, size) {}
		H* extractMin() { return BinaryHeap<H>::extract(); }
		void decreaseKey(int i, H k) { return BinaryHeap<H>::modify(i,k); }
};

int main() {	
	/*MaxBinaryHeap<int> *B = new MaxBinaryHeap<int>(100);
	B->enqueue(6)->enqueue(9)->enqueue(2)->enqueue(7)->enqueue(12);
	B->extractMax();
	B->enqueue(4)->enqueue(1)->enqueue(5);
	B->increaseKey(6,8);
	B->increaseKey(5,14);
	B->extractMax();
	B->print();*/
	
	int n = 100;
	int **V = new int*[n+1];                                      //'V' è un puntatore ad un array di puntatori ad interi.  esempio: v--> array[dim] --> int  
	for(int i=1; i<=n; i++) V[i] = new int(rand() % 100);         //Dunque  v--> v[i] --> 10(valore casuale)
	MinBinaryHeap<int> *B = new MinBinaryHeap<int>(V,n);
	B->print();
	B->sort();
	B->print();
	return 1;
}
