
#include<iostream>
using namespace std;
int	Matrix_Chain_Order(int *p, int n){
	int m[n][n];
	int s[n][n];
	int i,j,k,q;
	int min=0;
	int minimo=0;
	int size=n-1;
	for(i=1;i<n;i++){
    	m[i][i]=0;
	}
    for(i=2;i<=size;i++){
        for(j=1;j<=size-i+1;j++){
            k=j+i-1;
            m[j][k]=1000000000;
            for(q=j;q<=k-1;q++){
                min=m[j][q]+m[q+1][k]+p[j-1]*p[q]*p[k];
                if(min<m[j][k]){
                    m[j][k]=min;
                    minimo=min;
                    s[j][k]=q;
                }
            }
        }
	}
	return minimo;
}

int main(){
	int p[]={10,5,3,8,6,4};
	int n=6;
	cout<<"Numero minimo di moltiplicazioni"<<endl;
	cout<<Matrix_Chain_Order(p,n);
	return 1;
}
