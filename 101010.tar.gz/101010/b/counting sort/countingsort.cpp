#include<iostream>
#include<ctime>
#include<math.h>
using namespace std;

void countingsort(int *A, int n){
	int min=A[0];
	int max=A[0];
	for(int i=1;i<n;i++){
		if(A[i]>max) max=A[i];//trova massimo
		if(A[i]<min) min=A[i];//trova minimo
	}
	
	
	int range=max-min+1;
	int *C=new int[range];//crea vettore di supporto
	for(int i=0;i<range;i++) C[i]=0;//inizializza tutto a zero
	for(int i=0;i<n;i++) C[A[i]-min]++;//conta i valori
	int j=0;
	for(int k=0;k<range;k++){
		while(C[k]>0){
			A[j]=k+min;
			j++;
			C[k]--;//perch� bisogna mettere in A il valore tutte le volte che si presenta e quindi si porta a zero la posizione nel vettore di supporto
		}
	}
}

void print(int *A, int n){
	cout<<"A: ";
	for(int i=0;i<n;i++)
		cout<<A[i]<<" ";
	cout<<endl;
}

int main(){
	int A[]={5,7,12,45,21,2,3,20,18,13};
	int n=10;
	print(A,n);
	countingsort(A,n);
	print(A,n);
}
