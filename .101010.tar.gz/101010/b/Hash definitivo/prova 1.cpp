#include<iostream>
#include<ctime>
#include<math.h>
using namespace std;

template <class T> class Lista{
	virtual Lista<T>* insert(T x)=0;
	virtual Lista<T>* del(T x)=0;
	virtual int search(T x)=0;
	
};

template <class C> class Nodo{
	public:
		C key;
		Nodo<C>* next;
		Nodo<C>(C x){
			key=x;
			next=NULL;
		}	
};

template <class H> class LinkedList: public Lista<H>{
	public:
		Nodo<H>* testa;
		int size;
		LinkedList<H>(){
			testa=NULL;
			size=0;
		}
		
		LinkedList<H>* insert(H x){
			Nodo<H>* nuovo=new Nodo<H>(x);
			nuovo->next=testa;
			testa=nuovo;
			size++;
			return this;
		}
		
		LinkedList<H>* del(H x){
			Nodo<H>* temp=testa;
			Nodo<H>* y=NULL;
			while(temp!=NULL && temp->key!=x){
				y=temp;
				temp=temp->next;
			}
			if(temp!=NULL){
				y->next=temp->next;
				delete temp;
				size--;
			}
			return this;
		}
		
		int search(H x){
			Nodo<H>* temp=testa;
			while(temp!=NULL && temp->key!=x) temp=temp->next;
			if(temp!=NULL) return 1;
			else return 0;
		}
		
		void print(){
			Nodo<H>* temp=testa;
			while(temp!=NULL){
				cout<<temp->key<<" - ";
				temp=temp->next;
			}
			cout<<"//";
		}
};
