#include<iostream>
#include<ctime>
#include<math.h>
#include "prova 1.cpp"
using namespace std;
template <class H> class RBTree: public Albero<H>{
	public:
		static const int BLACK=0;
		static const int RED=1;
		
		void inorder_visit(Nodo<H>* n){
			if(n!=NULL){
				inorder_visit(n->left);
				cout<<"( "<<n->valore<<", "<<printC(n->color)<<" )";
				inorder_visit(n->right);
			}
		}
		
		void postorder_visit(Nodo<H>* n){
			if(n!=NULL){
				postorder_visit(n->left);
				postorder_visit(n->right);
				cout<<"( "<<n->valore<<", "<<printC(n->color)<<" )";
			}
		}
		
		void preorder_visit(Nodo<H>* n){
			if(n!=NULL){
				cout<<"( "<<n->valore<<", "<<printC(n->color)<<" )";
				preorder_visit(n->left);
				preorder_visit(n->right);
			}
		}
		
		char printC(int color){
			if(color==0) return 'B';
			if(color==1) return 'R';
			return 'X';
		}
		
		void RBInsertFixup(Nodo<H>* z){
			if(z->parent!=NULL && z->parent->color==BLACK) return;  //Se il padre del nodo esiste ed è nero allora non ci sono violazioni della proprietà degli alberi rosso-neri.
			if(z==this->radice){         //Se 'z' è la radice allora deve essere colorata nera
				z->color=BLACK;
				return;
			}
            
                        //determiniamo padre,nonno e zio del nodo 'z'
			Nodo<H>* padre=z->parent;
			Nodo<H>* nonno=padre->parent;
			Nodo<H>* zio=nonno->right;
			if(padre==nonno->right) zio=nonno->left;
                       
                        //Se lo zio esiste ed è rosso
			if(zio!=NULL && zio->color==RED){
				zio->color=BLACK;           //allora lo zio diventa nero
				padre->color=BLACK;         //il padre diventa nero
				nonno->color=RED;           //il nonno diventa rosso
				RBInsertFixup(nonno);       //invochiamo di nuovo il metodo ma sul nonno di 'z' per ripristnare la proprietà dell'albero rosso-nero
				return;
			}
			
                        //Se il padre corrisponde al figlio sinistro del nonno di 'z'
			if(padre==nonno->left){
				if(z==padre->right){              //e se 'z' è figlio destro
					this->leftRotate(padre);  //allora biosgna fare un left-rotate sul padre 
					padre=z;                  //quello che era 'z' diventa padre
					z=padre->left;            //e il nuovo 'z' diventa il figlio sinistro del padre ottenuto attraverso left-rotate
				}
				this->rightRotate(nonno);         //eseguiamo right-rotate sul nonno
				nonno->color=RED;                 //coloriamo di rosso il nonno
				padre->color=BLACK;               //e di nero il padre
				return;
			}
			else{
                                                                   //Se il padre di 'z' è figlio destro del nonno
				if(z==padre->left){                //e se 'z' proviene dalla sinistra del padre
					this->rightRotate(padre);  //allora eseguiamo right-rotate del padre
					padre=z;                   //quello che era 'z' diventa padre
					z=padre->right;            //e 'z' diventa il figlio destro del nuovo padre
				}
				nonno->color=RED;                  //il nonno diventa rosso
				padre->color=BLACK;                //il padre nero
				this->leftRotate(nonno);           //left-rotate del nonno
				return;
			}
		}
		
		void swapColor(Nodo<H>* x, Nodo<H>* y ){
			int temp=x->color;
			x->color=y->color;
			y->color=temp;
		}
		
		RBTree<H>():Albero<H>(){}
		
		RBTree<H>* insert(H key){
			Albero<H>:: insert(key);
			Nodo<H>* n=this->search(key);
			n->color=RED;
			RBInsertFixup(n);
			return this;
		}
		
		void inorder(){
			inorder_visit(this->radice);
			cout<<endl;
		}
		
		void postorder(){
			postorder_visit(this->radice);
			cout<<endl;
		}
		
		void preorder(){
			preorder_visit(this->radice);
			cout<<endl;
		}
};

int main(){
	RBTree<int> *t=new RBTree<int>();
	//t->insert(15)->insert(64)->insert(14)->insert(62)->insert(40)->insert(39)->insert(1)->insert(66)->insert(41);//->insert(1);
	t->insert(25)->insert(30)->insert(26)->insert(8)->insert(15)->insert(41)->insert(23);//->insert(66)->insert(36);
	t->inorder();
	t->postorder();
	t->preorder();
}

