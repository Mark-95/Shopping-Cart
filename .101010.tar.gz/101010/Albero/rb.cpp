#include <iostream>

using namespace std;

template <class T> class Nodo
{
   public:
      T valore;
      int colore;
      Nodo<T>* left;
      Nodo<T>*right;
      Nodo<T>*parent;
      Nodo<T>(T x)
      {
         valore=x;
         left=right=parent=NULL;
      }

};

template <class H> class RBtree
{
   public:
      Nodo<H>* root;
      RBtree<H>()
      {
         root=NULL;
      }

      RBtree<H>* insert(H x)
      {
          Nodo<H>* nuovo= new Nodo<H>(x);
	  Nodo<H>* temp=root;
          Nodo<H>* prec=NULL;
 
          while(temp!=NULL)
          {
             prec=temp;
             if(x>temp->valore) temp=temp->right;
             else temp=temp->left;
          }
 
          nuovo->parent=prec;
          if(prec==NULL) root=nuovo;
          else if(x>prec->valore) prec->right=nuovo;
          else prec->left=nuovo;
          nuovo->colore=1;
          RBfixedup(nuovo);
          return this;
      }

 
      void preorder(Nodo<H>*temp)
      {
         if(temp!=NULL)
         {
            if(temp->colore==0) cout<<"["<<temp->valore<<", B]"<<" / ";
	    if(temp->colore==1) cout<<"["<<temp->valore<<", R]"<<" / ";
            preorder(temp->left); 
	    preorder(temp->right); 
         }
      } 

      void print()
      {
         preorder(root);
         cout<<endl;
      }

      Nodo<H>* search(H x)
      {    
          Nodo<H>*temp=root;
          while(temp!=NULL && x!=temp->valore)
          {
             if(x>temp->valore) temp=temp->right;
             else temp=temp->left; 
          }

          if(temp!=NULL)
          {
	      cout<<"SEARCH: "<<temp->valore<<endl;	
              return temp;
          }
          else
          {	     
	      cout<<"SEARCH: NULL "<<endl;	
              return NULL;        
          }

      }

      Nodo<H>* rightrotate(Nodo<H>* y)
      {
         Nodo<H>* x= y->left;
         Nodo<H>* z= y->parent;
         y->left=x->right;
         x->right=y;
         
         if(z!=NULL)
         {
            if(y==z->right) z->right=x;
            else z->left=x;
         }else root=x; 
         x->parent=z;
         y->parent=x;
         if(y->right!=NULL) y->right->parent=y;
         return y;
      }

      Nodo<H>* leftrotate(Nodo<H>* y)
      {
         Nodo<H>* x= y->right;
         Nodo<H>* z= y->parent;
         y->right=x->left;
         x->left=y;
         
         if(z!=NULL)
         {
            if(y==z->right) z->right=x;
            else z->left=x;
         }else root=x; 
         x->parent=z;
         y->parent=x;
         if(y->left!=NULL) y->left->parent=y;
         return y;
      }

      void RBfixedup(Nodo<H>*z)
      {
         if(root==z)
         {
           z->colore=0;
           return;
         } 
         
         Nodo<H>* padre= z->parent;
         Nodo<H>* nonno=padre->parent;
         Nodo<H>* zio;
         if(padre!=NULL && padre->colore==0) return ;  
         if(padre==nonno->right) zio=nonno->left;
         else zio=nonno->right;
        
         if(zio!=NULL && zio->colore==1)
         {
             padre->colore=0;
             zio->colore=0;
             nonno->colore=1;
             RBfixedup(nonno);
             return;  
         }
 
         if(nonno->right==padre)
         { 
              if(z==padre->left)
              {
                  rightrotate(padre);
                  padre=z;
                  z=padre->right;
              }
              padre->colore=0;
              nonno->colore=1;
              leftrotate(nonno);
              return; 
         }else
         {
            if(z==padre->right)
              {
                  leftrotate(padre);
                  padre=z;
                  z=padre->left;
              }
              padre->colore=0;
              nonno->colore=1;
              rightrotate(nonno);
              return; 
         }
     

      }


      Nodo<H>*minimo(Nodo<H>* n)
      {
          if(n==NULL) return n;
          while(n->left!=NULL) n=n->left;

          return n;
      }

      Nodo<H>*massimo(Nodo<H>* n)
      {
          if(n==NULL) return n;
          while(n->right!=NULL) n=n->right;

          return n;
      }	

      Nodo<H>* predecessore(Nodo<H>*n)
      {
         if(n==NULL) return n;
         if(n->left) return massimo(n->left);
         Nodo<H>* temp=n->parent;
         while(temp!=NULL && n==temp->left)
         {
            n=temp;
            temp=temp->parent;
         }

         return temp; 
      }

      Nodo<H>* successore(Nodo<H>*n)
      {
         if(n==NULL) return n;
         if(n->right) return minimo(n->right);
         Nodo<H>* temp=n->parent;
         while(temp!=NULL && n==temp->right)
         {
            n=temp;
            temp=temp->parent;
         }

         return temp; 
      }


      Nodo<H>* delete_nodo(H x)
      {
         Nodo<H> *n=search(x);
         if(n==NULL) return n;
         Nodo<H>* p=n->parent;
          
         if(n->left==NULL)
         {
             if(p)
             {
               if(n==p->left) p->left=n->right;
               else p->right=n->right;
             }else root=n->right;

             return n;

         } 

         if(n->right==NULL)
         {
             if(p)
             {
               if(n==p->left) p->left=n->left;
               else p->right=n->left;
             }else root=n->left;
	
             return n;

         } 

         Nodo<H>* s=successore(n);
         del(s->valore);
         n->valore=s->valore;
         RBfixedup(n);
         return s;


      }


      RBtree<H>* del(H x)
      {
         delete_nodo(x);
         return this; 
      }

};

int main()
{
   RBtree<int> *p= new RBtree<int>();
   p->insert(30)->insert(12)->insert(0)->insert(2)->insert(25)->insert(15);
   p->print();
   cout<<"CANCELLA: "<<endl;
   p->del(25);
   p->print();
}
