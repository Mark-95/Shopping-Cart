#include <iostream>


using namespace std;

template <class T> class Lista
{
    public:
        virtual Lista<T> * insert(T x)=0;
	virtual Lista<T> * del(T x)=0;
        virtual int search(T x)=0;
    
};

template <class C> class Nodo 
{
   public:
       C key;
       Nodo<C>* next;
       Nodo<C>(C x)
       {
 	  key=x;
          next=NULL;
       }
};


template <class H> class LinkedList  : public Lista<H>
{
    public:
       Nodo<H> *root;
       int size;
       LinkedList<H>()
       {
          root=NULL;
          size=0;
       } 

       LinkedList<H> * insert(H x)
       {
          Nodo<H> * nuovo= new  Nodo<H>(x);
          nuovo->next=root;
          root=nuovo;
          size++;
          return this;
       }

       LinkedList<H> * del(H x)
       {
          Nodo<H> * tmp= root;
  	  Nodo<H> * prec=NULL;
          if(x==root->key)
	  {
             tmp=root;
             root=root->next;
             delete tmp;
             size--;
             return this;
          }

	  while(tmp!=NULL && tmp->key!=x) 
          {
             prec=tmp;
             tmp=tmp->next;
	  }

          if(tmp!=NULL)
          {
             prec->next= tmp->next;
             delete tmp;
             size--;
          }

          return this;
       }

       int search(H x)
       {
          Nodo<H> * tmp= root;
          
	  while(tmp!=NULL && tmp->key!=x) 
          {
             tmp=tmp->next;
	  }

          if(tmp!=NULL) return 1;
          else return 0;

       }
   
       void print()
       {
	  Nodo<H> * tmp= root;
          
	  while(tmp!=NULL) 
          {
             cout<<tmp->key<<" / ";
             tmp=tmp->next;
	  }
          cout<<endl;
       }
       
};

template <class B> class HashTable
{
    public:
         virtual HashTable<B>* insert(B x)=0;
	 virtual HashTable<B>* del(B x)=0;
	 virtual int search(B x)=0;
         virtual void print()=0;
};

template <class L> class LinkedHashTable : public HashTable<L>
{
    public:
         int m,size;
         LinkedList<L> ** t;
  
         LinkedHashTable<L>(int m)
         {
            this->m=m;
            size=0;
            t= new LinkedList<L>*[m];
            for(int i=0;i<m;i++) t[i] = new LinkedList<L>();
         }

	 int hashDiv(L x)
         {
            return ((int) x%this->m);
         }

         int hashMult(L x)
         {
            double c=0.7;
            double y= (int) x*c;
            double a=y-(int)y;
            return a*this->m;
         }

          HashTable<L>* insert(L x)
	  {
             int p=hashDiv(x);
             t[p]->insert(x);
             size++;
             return this;
          }

          int search(L x)
          {
             int p=hashDiv(x);
             return t[p]->search(x);
          }

	  HashTable<L>* del(L x)
	  {
             int p=hashDiv(x);
             if(t[p]->search(x)==1)
             {

	        t[p]->del(x);
                size--;
             }
             
             return this;
          }

	  void print()
          {
             for(int i=0;i<this->m;i++)
             {
                 cout<<"i: "<<i<<" "<<endl;
                 t[i]->print();
                 cout<<endl;
             }
          }

};

int main()
{

/*
   LinkedList<int> *p= new LinkedList<int>();
   p->insert(5)->insert(10)->insert(2)->insert(3)->insert(1)->insert(20);
   p->print();
   cout<<endl;
   cout<<"Trovato 3 ? "<<p->search(3)<<endl; 
   cout<<"Trovato 0 ? "<<p->search(0)<<endl; 
   p->del(1);
   p->print();
   p->del(5);
   p->print();
   p->del(20);
   p->print();

*/

   LinkedHashTable<int> *p = new LinkedHashTable<int>(5);
   p->insert(5)->insert(10)->insert(2)->insert(3)->insert(1)->insert(20);
   p->print();
   cout<<"DEL"<<endl;
   p->del(2);
   p->del(20);
   p->print();
   cout<<"SEARCH"<<endl;
   cout<<"Trovato 2 ? "<< p->search(2)<<endl;
   cout<<"Trovato 3 ? "<< p->search(3)<<endl;
   
 
  
   
}
