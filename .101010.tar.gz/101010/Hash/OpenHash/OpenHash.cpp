#include <iostream>

using namespace std;

template <class T> class HashTable
{
   public:
      virtual HashTable<T> * insert(T x)=0;
      virtual HashTable<T> * del(T x)=0;
      virtual int search(T x)=0;
      virtual void print()=0;  
};

template <class H> class OpenHash : public HashTable<H>
{
   public:
      int m,size;
      H** t;
      H* deleted;
 
      OpenHash<H>(int m)
      {
         this->m=m;
         size=0;
         t=new H*[m];
         deleted= new H();
         for(int i=0;i<m;i++) t[i]=NULL;
      }

      int hash(H x, int i)
      {
          return (x+i)%m;
      }

      HashTable<H> * insert(H x)
      {
         if(size==m) return this;
         int i=0;
         int p=hash(x,i);
         
         while(i<m && t[p]!=NULL && t[p]!=deleted)
         {
             i++;
             p=hash(x,i);
         }


         if(t[p]==NULL)
         {
             t[p]=new H(x);
             size++;
         }

         return this;

      }


      void print()
      {
          for(int i=0;i<m;i++)
          {
            if(t[i]!=NULL && t[i]!=deleted) cout<<"["<<i<<"]:"<<" "<<*t[i]<<" / ";
          }
          cout<<endl;
      }

      int search(H x)
      {
         int i=0;
         int p=hash(x,i);
 
         while(i<m && t[p]!=NULL)
         {
             if(t[p]!=deleted && *t[p]==x) return 1;
             i++;
             p=hash(x,i);
         }

         return 0;
      }

      HashTable<H> * del(H x)
      {
          int i=0;
          int p=hash(x,i);
 
          while(i<m && t[p]!=NULL)
          {

             if(t[p]!=NULL && *t[p]==x)
             {
                t[p]=deleted;
                size--;
                return this;
             }
             i++;
             p=hash(x,i);
          }

          return this; 
      } 

};


int main()
{
    OpenHash<int> *p = new OpenHash<int>(5);
    p->insert(2)->insert(5)->insert(0)->insert(20)->insert(10)->insert(3);
    p->print();    
    cout<<"TROVATO 5? "<<p->search(5)<<endl;
    cout<<"TROVATO 2? "<<p->search(2)<<endl;
    cout<<"TROVATO 3? "<<p->search(3)<<endl;
    cout<<"TROVATO 50? "<<p->search(50)<<endl;
    cout<<"CANCELLA 5"<<endl;
    cout<<"CANCELLA 2"<<endl;
    cout<<"CANCELLA 50"<<endl;
    p->del(5);
    p->del(2);
    p->del(50);
    p->print();
}
