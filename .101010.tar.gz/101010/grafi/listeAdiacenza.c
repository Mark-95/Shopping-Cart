/*implementazione di un grafo mediante liste di adiacenza*/
#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#define dim 6
#define BIANCO 0
#define ROSSO 1
#define VERDE 2
typedef int nodo;
typedef struct struct_grafo *grafo;

struct struct_grafo {
    lista A[dim];
    nodo visit[dim];
    int comp[dim];
    int colore[dim];
};
typedef int tree[dim];

void BFS(grafo, nodo);
void DFS(grafo, nodo);
int COMP_CONNESSE(grafo, int);
void DFS_CONNESSE(grafo, nodo, int);
void ALBERO_DFS(grafo, nodo, tree, nodo);
void adiacenza(grafo, nodo);
grafo creaGrafo();
void addArco(grafo, nodo, nodo);
void reset(grafo);
int BIPARTITO(grafo, nodo);

int main() {

    grafo g = creaGrafo();

    addArco(g, 0, 1);
    addArco(g, 0, 3);

    addArco(g, 1, 0);
    addArco(g, 1, 4);
    addArco(g, 1, 5);
    addArco(g, 1, 2);

    addArco(g, 2, 4);
    addArco(g, 2, 3);
    addArco(g, 2, 5);
    addArco(g, 2, 1);

    addArco(g, 3, 2);
    addArco(g, 3, 0);
    addArco(g, 3, 4);

    addArco(g, 4, 3);
    addArco(g, 4, 0);
    addArco(g, 4, 1);

    addArco(g, 5, 1);
    addArco(g, 5, 2);
    reset(g);
    tree T;
    ALBERO_DFS(g, 3, T, -1);
    int i;
    printf("Albero di copertura del grafo:\n");
    for (i = 0; i < dim; i++)printf("%d\t", T[i]);
    reset(g);
    printf("\n visita DFS partendo dal nodo 2:\n");
    DFS(g,2);
    reset(g);
    printf("\n visita DFS partendo dal nodo 1:\n");
    BFS(g,1);
    reset(g);
    if(BIPARTITO(g,1))printf("\nIl grafo è bipartito");
    else printf("\nIl grafo non è bipartito");

    printf("\nIl grafo ha %d componenti connesse\n",COMP_CONNESSE(g,dim));

    return 0;
}

int BIPARTITO(grafo G, nodo r) {
    nodo v, u;
    int bipartito = 1;
    lista L;
    posizione p;
    coda Q = CREACODA();
    INCODA(r, Q);
    G->colore[r] = ROSSO;
    while (!CODAVUOTA(Q) && bipartito) {
        u = LEGGICODA(Q);
        FUORICODA(Q);
        L = G->A[u];
        p = PRIMOLISTA(L);
        while (!FINELISTA(p, L)) {
            v = LEGGILISTA(p);
            if (G->colore[v] == BIANCO) {
                G->colore[v] = (G->colore[u] == ROSSO) ? VERDE : ROSSO;
                INCODA(v, Q);
            } else {
                if (G->colore[u] == G->colore[v]) {
                    bipartito = 0;
                }
            }
            p = SUCCLISTA(p);
        }
    }
    return bipartito;
}
/*traminte una visita DFS del grafo si crea l'albero di copertura del grafo
 albero implementato tramite vettore dei padri
 */
void ALBERO_DFS(grafo G, nodo u, tree T, nodo padre) {
    nodo v;
    /*marca u come visitato*/
    G->visit[u] = 1;
    T[u] = padre;
    lista L = G->A[u];
    posizione p = PRIMOLISTA(L);
    /*per ogni v appartenente a A(u) */
    while (!FINELISTA(p, L)) {
        v = LEGGILISTA(p);
        /*se v non è stato visitato */
        if (!G->visit[v]) {
            ALBERO_DFS(G, v, T, u);
        }
        p = SUCCLISTA(p);
    }
}

/*calcola il numero di componenti connesse del grafo*/
int COMP_CONNESSE(grafo G, int n) {
    int i;
    int numComp = 0;
    for (i = 0; i < n; i++) {
        G->comp[i] = 0;
    }
    for (i = 0; i < n; i++) {
        if (G->comp[i] == 0) {
            numComp++;
            DFS_CONNESSE(G, i, numComp);
        }
    }
    return numComp;
}

/*visita DFS per la ricerca delle componenti connesse*/
void DFS_CONNESSE(grafo G, nodo u, int numComp) {
    nodo v;
    G->comp[u] = numComp;
    lista L = G->A[u];
    posizione p = PRIMOLISTA(L);
    while (!FINELISTA(p, L)) {
        v = LEGGILISTA(p);
        if (G->comp[v] == 0) {
            DFS_CONNESSE(G, v, numComp);
        }
        p = SUCCLISTA(p);
    }
}

/* visita DFS */
void DFS(grafo G, nodo u) {
    nodo v;
    G->visit[u] = 1; /*marca u come visitato*/
    printf("(%d)\t", u);
    lista L = G->A[u];
    posizione p = PRIMOLISTA(L);
    while (!FINELISTA(p, L)) {/*per ogni v appartenente a A(u) */
        v = LEGGILISTA(p);
        /*se v non è stato visitato */
        if (!G->visit[v]) {
            DFS(G, v);
        }
        p = SUCCLISTA(p);
    }
}

/* visita BFS */
void BFS(grafo G, nodo r) {
    lista L;
    posizione p;
    nodo v;
    nodo u;
    coda Q = CREACODA();
    INCODA(r, Q);
    while (!CODAVUOTA(Q)) {
        v = LEGGICODA(Q);
        FUORICODA(Q);
        G->visit[v] = 1;
        printf("%d\t", v);
        L = G->A[v];
        p = PRIMOLISTA(L);
        while (!FINELISTA(p, L)) {
            u = LEGGILISTA(p);
            if (!G->visit[u] && !APPARTCODA(u, Q)) {
                INCODA(u, Q);
            }
            p = SUCCLISTA(p);
        }
    }
}

void addArco(grafo G, nodo par, nodo arr) {
    lista L = G->A[par];
    posizione p = PRIMOLISTA(L);
    INLISTA(arr, &p);
}

/* visualizza insieme di adiacenza di un nodo */
void adiacenza(grafo G, nodo u) {
    lista L;
    posizione p;
    nodo v;
    L = G->A[u];
    p = PRIMOLISTA(L);
    while (!FINELISTA(p, L)) {
        v = LEGGILISTA(p);
        printf("(%d)---->(%d)\n", u, v);
        p = SUCCLISTA(p);
    }
}

grafo creaGrafo() {
    grafo G = malloc(sizeof (struct struct_grafo));
    nodo i;
    for (i = 0; i < dim; i++) {
        G->A[i] = CREALISTA();
        G->visit[i] = 0;
        G->colore[i] = BIANCO;
        G->comp[i] = 0;
    }
}

void reset(grafo G) {
    nodo i;
    for (i = 0; i < dim; i++) {
        G->visit[i] = 0;
        G->colore[i] = BIANCO;
        G->comp[i] = 0;
    }
}
