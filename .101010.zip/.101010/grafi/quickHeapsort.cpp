#include <iostream>


using namespace std;
/*
template <class H> class QuickHeapsort
{
    public:

        int len;
        int* A;

        QuickHeapsort<H>(int len)
        {
           this->len=len;
           A= new int[len];
        } 

        void Quick_Heapsort() 
        
};*/

void scambia(int *A, int i, int j)
{
   int tmp= A[i];
   A[i]=A[j];
   A[j]= tmp;
}

void maxHeapify(int i, int heapsize)
{
   if(i>heapsize)return;
   int l= i<<1;
   int r= i<<1|1;
   int m=i;

   if(l<=heapsize && A[m]<A[l]) m=l;
   if(r<=heapsize && A[m]<A[r]) m=r;
   if(m==i) return;
   scambia(A,m,i);
   maxHeapify(m,heapsize);
}

void buildMaxHeap(int *A, int n)
{
    for(int i=n/2;i>0;i--) maxHeapify(i,n);
}

void minHeapify(int i, int heapsize)
{
   if(i>heapsize)return;
   int l= i<<1;
   int r= i<<1|1;
   int m=i;

   if(l<=heapsize && A[m]>A[l]) m=l;
   if(r<=heapsize && A[m]>A[r]) m=r;
   if(m==i) return;
   scambia(A,m,i);
   minHeapify(m,heapsize);
}

void buildMinHeap(int *A, int n)
{
    for(int i=n/2;i>0;i--) minHeapify(i,n);
}

void QuickHeapsort(int *A, int left, int right)
{
   int n=right;
   int pivot;

   if(n>1)
   {
      //pivot= choosePivot(A);           //?
      //m= partitionReverse(A,pivot);    //?

      if( m<= ((n+1)/2) )
      {
         int dim=m-1;
         int L[dim];
         int R[dim];
         int j=1;
         for(int i=1; i<=m-1; i++) 
         {
            L[j]=A[i];
            j++;
         }
 
         j=1;
         for(int i=n-m+2; i<=n; i++) 
         {
            R[j]=A[i];
            j++;
         }

         externalMaxHeapsort(L,R,dim);     
         scambia(A, m, n-m+1); 

         left=1;
         right=n-m;
         QuickHeapsort(A,left,right);          
      }else
      {
         int dim=n-m;
         int L[dim];
         int R[dim];
         int j=1;
         for(int i=m+1; i<=n; i++) 
         {
            L[j]=A[i];
            j++;
         }
 
         j=1;
         for(int i=1; i<=n-m; i++) 
         {
            R[j]=A[i];
            j++;
         }

         externalMinHeapsort(L,R,dim);       
         scambia(A, m, n-m+1);
 
         left=n-m+2;
         right=n;
         QuickHeapsort(A,left,right); 
      }
   }
}

void externalMaxHeapsort(int *A,int * Ext, int n)
{
   buildMaxHeap(A,n);
   for(int j=1;j<=n; j++)
   {
      int temp=Ext[j];
      Ext[j]=A[1];
      int l=MaxSpecialLeaf(A,n);
      A[l]=temp;
   }
}

void externalMinHeapsort(int *A,int * Ext, int n)
{
   buildMinHeap(A,n);
   for(int j=1;j<=n; j++)
   {
      int temp=Ext[j];
      Ext[j]=A[1];
      int l=MinSpecialLeaf(A,n);
      A[l]=temp;
   }
}

int MaxSpecialLeaf(int *A, int n)
{
   int i=2;
   while(i<n)
   {
      if(A[i]<A[i+1]) i++;
      A[i/2]=A[i];
      i=i*2;
   }

   if(i==n)
   {
     A[i/2]=A[n];
     i=i*2;
   }
   return i/2;
}

int MinSpecialLeaf(int *A, int n)
{
   int i=2;
   while(i<n)
   {
      if(A[i]>A[i+1]) i++;
      A[i/2]=A[i];
      i=i*2;
   }

   if(i==n)
   {
     A[i/2]=A[n];
     i=i*2;
   }
   return i/2;
}

int main()
{

}


