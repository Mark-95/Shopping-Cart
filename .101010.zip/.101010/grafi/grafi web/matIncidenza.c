/*implementazione di un grafo mediante matrice di incidenza*/
#include <stdlib.h>
#include <stdio.h>
#include "myLib.h"
#define BIANCO 0
#define ROSSO 1
#define VERDE 2
#define row 5
#define col 8

typedef int matrice_incidenza[row][col];
typedef matrice_incidenza grafo;
typedef int nodo;
typedef int arco;

void BFS(grafo, nodo, int[]);
void DFS(grafo, nodo, int[]);
void adiacenza(grafo, nodo);
int BIPARTITO(grafo, nodo, int[]);
int COMP_CONNESSE(grafo, int);
int BIPARTITO(grafo, nodo, int[]);
void DFS_CONNESSE(grafo, nodo, int, int[]);
void reset(int[]);

int main() {

    grafo g = {
        /*    0     1     2     3     4     5     6     7*/
        /*  (0,1) (0,2) (1,2) (1,3) (2,4) (3,0) (3,4) (4,1) */
        /*0*/{-1,  -1,    0,    0,    0,    1,    0,    0},
        /*1*/{1,    0,   -1,   -1,    0,    0,    0,    1},
        /*2*/{0,    1,    1,    0,   -1,    0,    0,    0},
        /*3*/{0,    0,    0,    1,    0,   -1,   -1,    0},
        /*4*/{0,    0,    0,    0,    1,    0,    1,   -1}
    };

    int vivitato[row], colore[row];
    reset(vivitato);
    printf("\n\n visita DFS partendo dal nodo 2:\n");
    DFS(g,2,vivitato);
    reset(vivitato);
    printf("\n visita DFS partendo dal nodo 1:\n");
    BFS(g,1,vivitato);
    reset(colore);
    if(BIPARTITO(g,1,colore))printf("\nIl grafo è bipartito");
    else printf("\nIl grafo non è bipartito");

    printf("\nIl grafo ha %d componenti connesse\n",COMP_CONNESSE(g,row));
    return 0;
}

int BIPARTITO(grafo G, nodo r, int colore[]) {
    int flag, bipartito = 1;
    arco e;
    nodo u, v;
    coda Q = CREACODA();
    INCODA(r, Q);
    colore[r] = ROSSO;
    while (!CODAVUOTA(Q) && bipartito) {
        u = LEGGICODA(Q);
        FUORICODA(Q);
        /* per ogni arco */
        for (e = 0; e < col; e++) {
            /* uscente da u */
            if (G[u][e] == -1) {
                v = 0;
                flag = 0;
                while (v < row && !flag) {
                    /*se v appartiene a A(u) e non è stato visitato*/
                    if (G[v][e] == 1) {
                        if (colore[v] == BIANCO) {
                            colore[v] = (colore[u] == ROSSO) ? VERDE : ROSSO;
                            INCODA(v, Q);
                        } else {
                            if (colore[u] == colore[v]) {
                                bipartito = 0;
                            }
                        }
                    }
                    v++;
                }
            }
        }
    }
    return bipartito;
}

int COMP_CONNESSE(grafo G, int n) {
    int i;
    int numComp = 0;
    int comp[n];
    for (i = 0; i < row; i++) {
        comp[i] = 0;
    }
    for (i = 0; i < n; i++) {
        if (comp[i] == 0) {
            numComp++;
            DFS_CONNESSE(G, i, numComp, comp);
        }
    }
    return numComp;
}

void DFS_CONNESSE(grafo G, nodo u, int numComp, int comp[]) {
    arco e;
    nodo v;
    int flag;
    comp[u] = numComp;
    /* per ogni arco */
    for (e = 0; e < col; e++) {
        /* uscente da u */
        if (G[u][e] == -1) {
            v = 0;
            flag = 0;
            while (v < row && !flag) {
                /*se v appartiene a A(u) e non è stato visitato*/
                if (G[v][e] == 1) {
                    if (comp[v] == 0) {
                        DFS_CONNESSE(G, v, numComp, comp);
                        flag = 1;
                    }
                }
                v++;
            }
        }
    }
}

void DFS(grafo G, nodo u, int visitato[]) {
    arco e;
    nodo v;
    int flag;
    visitato[u] = 1;
    printf("%d\t", u);
    /* per ogni arco */
    for (e = 0; e < col; e++) {
        /* uscente da u */
        if (G[u][e] == -1) {
            v = 0;
            flag = 0;
            while (v < row && !flag) {
                /*se v appartiene a A(u) e non è stato visitato*/
                if (G[v][e] == 1) {
                    if (!visitato[v]) {
                        DFS(G, v, visitato);
                        flag = 1;
                    }
                }
                v++;
            }
        }
    }
}

void BFS(grafo G, nodo r, int visitati[]) {
    int flag;
    arco e;
    nodo u, v;
    coda Q = CREACODA();
    INCODA(r, Q);
    while (!CODAVUOTA(Q)) {
        u = LEGGICODA(Q);
        FUORICODA(Q);
        visitati[u] = 1;
        printf("%d\t", u);
        /* per ogni arco */
        for (e = 0; e < col; e++) {
            /* uscente da u */
            if (G[u][e] == -1) {
                v = 0;
                flag = 0;
                while (v < row && !flag) {
                    /*se v appartiene a A(u) e non è stato visitato*/
                    if (G[v][e] == 1) {
                        if (!visitati[v] && !APPARTCODA(v, Q)) {
                            INCODA(v, Q);
                            flag = 1;
                        }
                    }
                    v++;
                }
            }
        }
    }
}

void adiacenza(grafo G, nodo u) {
    int flag;
    arco e;
    nodo v;
    for (e = 0; e < col; e++) {
        if (G[u][e] == -1) {
            v = 0;
            flag = 0;
            while (v < row && !flag) {
                if (G[v][e] == 1) {
                    printf("(%d)---%d--->(%d)\n", u, e, v);
                    flag = 1;
                }
                v++;
            }
        }
    }
}

void reset(int v[]) {
    int i;
    for (i = 0; i < row; i++) {
        v[i] = 0;
    }
}