/*implementazione di un grafo mediante vettore di adiacenza*/
#include <stdio.h>
#include <stdlib.h>
#include "myLib.h"
#define N 6
#define A 18	
#define BIANCO 0
#define ROSSO 1
#define VERDE 2
typedef struct grafo_struct *grafo;
typedef int nodo;

struct grafo_struct {
    int nodi[N + 1];
    int archi[A];
    int visit[N];
    int comp[N];
    int inCoda[N];
    int colore[N];
};
void BFS(grafo, nodo);
void DFS(grafo, nodo);
int COMP_CONNESSE(grafo, int);
void DFS_CONNESSE(grafo, nodo, int);
void stampa(grafo);
void reset(grafo);
void adiacenza(grafo, nodo);
int BIPARTITO(grafo, nodo);

int main() {

    grafo G = malloc(sizeof (struct grafo_struct));

    int n[] = {0, 2, 6, 10, 13, 16, 18};
    int a[] = {3, 1, 2, 5, 4, 0, 1, 5, 3, 4, 4, 0, 2, 1, 0, 3, 2, 1};
    int i;
// init to graph
    for (i = 0; i < N + 1; i++) {
        G->nodi[i] = n[i];
    }
    for (i = 0; i < A; i++) {
        G->archi[i] = a[i];
    }
    for (i = 0; i < N; i++) {
        G->visit[i] = 0;
        G->inCoda[i] = 0;
        G->colore[i] = BIANCO;
    }
//***********
    stampa(G);
    printf("\n visita DFS partendo dal nodo 2:\n");
    DFS(G,2);
    reset(G);
    printf("\n visita DFS partendo dal nodo 1:\n");
    BFS(G,1);
    reset(G);
    if(BIPARTITO(G,1))printf("\nIl grafo è bipartito");
    else printf("\nIl grafo non è bipartito");

    printf("\nIl grafo ha %d componenti connesse\n",COMP_CONNESSE(G,N));
    return 0;
}

int BIPARTITO(grafo G, nodo r) {
    nodo v, u;
    int bipartito = 1;
    int i;
    coda Q = CREACODA();
    INCODA(r, Q);
    G->colore[r] = ROSSO;
    while (!CODAVUOTA(Q) && bipartito) {
        u = LEGGICODA(Q);
        FUORICODA(Q);
        for (i = G->nodi[u]; i < G->nodi[u + 1]; i++) {
            v = G->archi[i];
            if (G->colore[v] == BIANCO) {
                G->colore[v] = (G->colore[u] == ROSSO) ? VERDE : ROSSO;
                INCODA(v, Q);
            } else {
                if (G->colore[u] == G->colore[v]) {
                    bipartito = 0;
                }
            }
        }
    }
    return bipartito;
}

/*calcola il numero di componenti connesse del grafo*/
int COMP_CONNESSE(grafo G, int n) {
    int i;
    int numComp = 0;
    for (i = 0; i < n; i++) {
        G->comp[i] = 0;
    }
    for (i = 0; i < n; i++) {

        if (G->comp[i] == 0) {
            numComp++;
            DFS_CONNESSE(G, i, numComp);
        }
    }
    return numComp;
}

/*visita DFS per la ricerca delle componenti connesse*/
void DFS_CONNESSE(grafo G, nodo u, int numComp) {
    nodo v;
    G->comp[u] = numComp;
    int i;
    for (i = G->nodi[u]; i < G->nodi[u + 1]; i++) {
        v = G->archi[i];
        if (G->comp[v] == 0) {
            numComp++;
            DFS_CONNESSE(G, v, numComp);
        }
    }
}

void DFS(grafo G, nodo u) {
    nodo v;
    G->visit[u] = 1;
    printf("(%d)\t", u);
    int i;
    for (i = G->nodi[u]; i < G->nodi[u + 1]; i++) {
        v = G->archi[i];
        if (!G->visit[v]) {
            DFS(G, v);
        }
    }
}

void BFS(grafo G, nodo r) {
    nodo v, u;
    int i;
    coda Q = CREACODA();
    INCODA(r, Q);
    G->visit[r] = 1;
    while (!CODAVUOTA(Q)) {
        u = LEGGICODA(Q);
        FUORICODA(Q);
        G->visit[u] = 1;
        printf("%d\t", u);
        for (i = G->nodi[u]; i < G->nodi[u + 1]; i++) {
            v = G->archi[i];
            if (!G->visit[v] && !APPARTCODA(v, Q)) {
                INCODA(v, Q);
            }
        }
    }
}

void adiacenza(grafo G, nodo u) {
    int i;
    nodo v;
    for (i = G->nodi[u]; i < G->nodi[u + 1]; i++) {
        v = G->archi[i];
        printf("(%d)---->(%d)\n", u, v);
    }
}
//inizializza G->visit[i] = 0 dipo una visita(DFS/BFS) del grafo

void reset(grafo G) {
    int i;
    for (i = 0; i < N; i++) {
        G->visit[i] = 0;
    }
    for (i = 0; i < N; i++) {
        G->inCoda[i] = 0;
    }
}

void stampa(grafo G) {
    int i;
    printf("\n\n******** GRAFO ********\n\n* vettore nodi:\n\n");
    for (i = 0; i < N + 1; i++) {
        printf("%d\t", G->nodi[i]);
    }
    printf("\n\n* vettore archi:\n\n");
    for (i = 0; i < A; i++) {
        printf("%d\t", G->archi[i]);
    }
    printf("\n\n* vettore visit:\n\n");
    for (i = 0; i < N; i++) {
        printf("%d\t", G->visit[i]);
    }
    printf("\n\n* vettore inCoda:\n\n");
    for (i = 0; i < N; i++) {
        printf("%d\t", G->inCoda[i]);
    }
    printf("\n\n***********************\n");
}
