#include <iostream>
#include <ctime>
#include <math.h>
#include "List.cpp"
using namespace std;

#define W 0
#define G 1
#define B 2
#define inf len+1

class Queue 
{
	public:
		int len;                     
                int n;                        
                int head;                     
                int tail;                    
		int *q;                       
		
		Queue(int len)
                {
			this->len = len;
			q = new int[len];
			n = 0;
			head = tail = 0;
		}

		int isEmpty() { return n==0; } 

		void push(int x) 
                {
			q[tail] = x;          
			tail = (tail+1)%len;  
			n++;                  
		}
		
		int pop() 
                {
		   if(n>0)                      
                   {
			int t = q[head];        
			head = (head+1) % len;  
			n--;                    
			return t;               
		   }

		   return -1;                   
		}
	
};

template <class H> class MGraph {
	private:
		int len;                             
                int n;                               
                int m;                               
		int **M;                             
		int t;
		H **K;                               
		int *d, *p, *f, *c, *r;
		int current_root;
		int lastBFSSource;
		
		
		int findIndex(H x) {
			for(int i=0; i<n; i++)
				if(*K[i] == x) return i;
			return -1;
		}
		

                //stampa il cammino di un nodo
		void printPath(int x) {
			if(x==-1) return;                  
			if(p[x]==-1) cout << x;            
			else {
				printPath(p[x]);           
				cout << "->" << x;         
			}
		}
		
		void sort(int *a, int n, int *k) {
			for(int i=1; i<n; i++) {
				int j = i-1;
				while(j>=0 && k[a[j+1]]>k[a[j]]) {
					int t = a[j+1];
					a[j+1] = a[j];
					a[j] = t;
					j--;
				}
			}
		}
		
	public:
		MGraph(int len) {
			this->len = len;
			n = m = 0;
			d = new int[len];
			p = new int[len];
			f = new int[len];
			c = new int[len];
			r = new int[len];
			M = new int*[len];

                        //Inizializzo la matrice
			for(int i=0; i<len; i++) 
                        {
			    M[i] = new int[len];      

			    for(int j=0; j<len; j++) 
                            {
                               M[i][j] = 0;
                            }
			}

			K = new H*[len];                       
			for(int i=0; i<len; i++) K[i] = NULL;  
			lastBFSSource = -1;
		}

		
		MGraph<H>* addNode(H k)
                {
			if(n==len) return this;                
			if(findIndex(k)>=0) return this;       
			K[n] = new H(k);                       
			n++;	                               
			return this;
		}

		
		MGraph<H>* addEdge(H x, H y) 
                {
			int i = findIndex(x);                  
			int j = findIndex(y);	               
			if(i<0 || j<0) return this;            

			if(!M[i][j])                           //se M[i][j]==0 allora l'arco non esiste
                        {
			   M[i][j] = 1;                        
			   m++;                                
			}
			return this;
		}
		
		void print() 
                {
		    for(int i=0; i<n; i++) 
                    {
			cout << "(" << i << ", " << *K[i] << ")" << " : ";   

			for(int j=0; j<n; j++) 
                        {
                            //Se M[i][j]==1

			    if(M[i][j]) cout << *K[j] << " ";                
			} 
			cout << endl;
		    }
		}
		
		void BFS(int s) {
			int c[len];                  
			Queue *Q = new Queue(len);   //nella coda saranno inseriti tutti i nodi scoperti, colorati di grigio(G)

			//inizializzo.
			for(int i=0; i<n; i++) {
				c[i] = W;            
				p[i] = -1;           
				d[i] = inf;           
			}

			Q->push(s);                 
			c[s] = G;                    
			d[s] = 0;	             

			while(!Q->isEmpty())         //fino a quando la coda non è vuota
                        {
			    int x = Q->pop();        
			    for(int i=0; i<n; i++) 
                            {
                                  
				if(M[x][i]==1)       
                                {
				    if(c[i]==W)         
                                    {
					c[i] = G;       
					Q->push(i);     
					p[i] = x;       
					d[i] = d[x]+1;   
				    }
				} 
			    }

		            
			    c[x] = B;           
			}

			lastBFSSource = s;              

	                //stampa l'altezza di ogni nodo a partire dal nodo 's'.
			for(int i=0; i<n; i++) {
				cout << "[" << i << "]->";
				if(d[i]==inf) cout << "inf." << endl;
				else cout << d[i] << endl;
			}
			cout << endl;
		}
		


		void BFS(H x) {
			int s = findIndex(x);
			if(s>=0) BFS(s);
		}
		

	        //determina la minima distanza tra due nodi
		int minDist(H x, H y) {            
			int s = findIndex(x);
			if(s==-1) return inf;
			if(lastBFSSource!=s) BFS(s); 
			int t = findIndex(y);
			if(t==-1) return inf;
			return d[t];
		}

                //determina il cammino tra i nodi 'x' e 'y'
		void minPath(H x, H y) {
			int s = findIndex(x);
			int t = findIndex(y);
			if(t==-1 || s==-1) {
				cout << "Non esiste alcun cammino" << endl;
				return;
			}
			if(lastBFSSource!=s) BFS(s);
			printPath(t);
			cout << endl;
		}
		
                
		int DFSVisit(int v) {
			//cout << "(" << v << ") " << endl;
			int cycle = 0;
			c[v] = G;                                        
			d[v] = t++;                                      
			r[v] = current_root;   
                            
			for(int u=0; u<n; u++) 
                        {
			    if(M[v][u]==1) 
                            {
				if(c[u]==W) 
                                {
				    p[u]=v;
				    cycle |= DFSVisit(u);
				}

				if(c[u]==G) cycle = 1;
			    }
			}

			c[v] = B;
			f[v] = t++;
			return cycle;		
		}
		
		int DFS() {
			int cycle = 0;
			t = 0;

                        //inizializzazione dei nodi
			for(int i=0; i<n; i++) 
                        {
				c[i] = W;             
				p[i] = -1;           
			}


			for(int i=0; i<n; i++)
			{
           	           if(c[i]==W) 
                           {
				current_root = i;
				cycle |= DFSVisit(i);
			   }
                        }

			//for(int i=0; i<n; i++)
			//	cout << "[" << i << "] : " << r[i] << endl;
			return cycle;
		}
		
		void topSort() {
			int cycle = DFS();
			if(cycle) {
				cout << "Il grafo contiene un ciclo";
				return;
			}
			int *s = new int[n];
			for(int i=0; i<n; i++) s[i] = i;
			sort(s,n,f);
			for(int i=0; i<n; i++) {
				cout << "(" << s[i] << ", " << f[s[i]] << ") ";
			}
			cout << endl;
		}
		
		void getCC(int v) {
			int **T;
			T = new int*[n];
			for(int i=0; i<n; i++) {
				T[i] = new int[n];
				for(int j=0; j<n; j++)
					T[i][j] = M[j][i];
			}
			for(int i=0; i<n; i++) {
				c[i] = W;
				p[i] = -1;
			}
			DFSVisit(v);
			int *r = new int[n];
			for(int i=0; i<n; i++) if(c[i]==B) r[i]=B;
			int **F = M;
			M = T;
			for(int i=0; i<n; i++) {
				c[i] = W;
				p[i] = -1;
			}
			DFSVisit(v);
			M = F;
			for(int i=0; i<n; i++) if(r[i]==B && c[i]==B) cout << i << " ";
			cout << endl;
		}
		
		void print_scc() {
			for(int i=0; i<n; i++) {
				if(r[i]>=0) {
					int root = r[i];
					cout << "{ ";
					for(int j=i; j<n; j++) {
						if(r[j]==root) {
							cout << j << " ";
							r[j] = -1;
						}
					}
					cout << "} ";
				}
			}
			cout << endl;
		}

		void print_scc2() {
			int *s = new int[n];
			for(int i=0; i<n; i++) s[i] = i;
			sort(s,n,r);
			int i = 0;
			while(i<n) {
				cout << "{ ";
				int root = r[s[i]];
				while(i<n && r[s[i]]==root) {
					cout << s[i] << " ";
					i++;
				}
				cout << "} ";
			}
			cout << endl;
		}
		
		void SCC() {
			DFS();
			int *s = new int[n];
			for(int i=0; i<n; i++) s[i] = i;
			sort(s,n,f);
			int **T;
			T = new int*[n];
			for(int i=0; i<n; i++) {
				T[i] = new int[n];
				for(int j=0; j<n; j++)
					T[i][j] = M[j][i];
			}
			int **F = M;
			M = T;
			for(int i=0; i<n; i++) {
				c[i] = W;
				p[i] = -1;
			}
			for(int i=0; i<n; i++)
				if( c[s[i]]==W ) {
					current_root = s[i];
					DFSVisit(s[i]);
				}
			print_scc2();
		}
};









//Grafo attraverso lista di adiacenza
template <class H> class LGraph {
	private:

		int len;                             
                int n;                              
                int m;                               
		H **K;                               

	        
		LinkedList<int> **Adj;               

                
		int findIndex(H x) {
			for(int i=0; i<n; i++)
				if(*K[i] == x) return i;
			return -1;
		}
	
	public:
		LGraph(int len) {
			this->len = len;
			n = m = 0;
			K = new H*[len];

			for(int i=0; i<len; i++) K[i] = NULL;  

			Adj = new LinkedList<int>*[len];

			for(int i=0; i<len; i++) 
				Adj[i] = new LinkedList<int>();
		}


	        
		LGraph<H>* addNode(H k) {
			if(n==len) return this;           
			if(findIndex(k)>=0) return this;  
			K[n] = new H(k);                  
			n++;                              
			return this;
		}
		

		
		LGraph<H>* addEdge(H x, H y) {
			int i = findIndex(x);           
			int j = findIndex(y);            
			if(i<0 || j<0) return this;      

	                 
 
			if(!Adj[i]->search(j))           //Se non esiste         
                        {
			    Adj[i]->insert(j);           
			    m++;                        
			}
			return this;
		}
		
		void print() 
                {
                   
		   for(int i=0; i<n; i++) 
                   {
			cout << "(" << i << ", " << *K[i] << ")" << " : ";  
			Adj[i]->print();                                    
			cout << endl;
	           }
		}		
		

};



int main() {
	MGraph<char> *Gr = new MGraph<char>(9);
	Gr->addNode('0')->addNode('1')->addNode('2')->addNode('3');
	Gr->addNode('4')->addNode('5')->addNode('6')->addNode('7');
	Gr->addNode('8');
	
	Gr->addEdge('0','8')->addEdge('0','1');
	Gr->addEdge('1','8');
	Gr->addEdge('2','4');
	Gr->addEdge('3','5')->addEdge('3','6')->addEdge('3','7');
	Gr->addEdge('4','3')->addEdge('4','0');
	Gr->addEdge('5','6')->addEdge('5','3');
	Gr->addEdge('6','5');
	Gr->addEdge('8','2');
	Gr->print();
	Gr->SCC();
		
	
}



/*
#include <iostream>
#include <ctime>
#include <math.h>
#include "List.cpp"
using namespace std;

#define WHITE 0
#define GREY  1
#define BLACK 2

template <class C> class NodeG {
	private:
		C key;
		int indegree, color;
		LinkedList< NodeG<C>* >* Adj;
		
	public:
		NodeG<C>(C key) {
			this->key = key;
			indegree = 0;
			color = WHITE;
			Adj = new LinkedList< NodeG<C>* >();
		}
		
		void setKey(C key) {
			this->key = key;
		}
		void setColor(int color) {
			this->color = color;
		}
		C getKey() {
			return key;
		}
		int getOutDegree() {
			return Adj->size();
		}
		int getColor() {
			return color;
		}
		int getInDegree() {
			return indegree;
		}
		LinkedList< NodeG<C>* >* getAdj() {
			return Adj;
		}
		void incInDegree() { indegree++; }
		void decInDegree() { indegree--; }
};

template <class T> class Graph {
	private:
		int n,m,len;
		int time;
		int *d, *f;
		NodeG<T>** p;
		NodeG<T> **G;
		NodeG<T>* search(T k) {
			for(int i=0; i<n; i++) 
				if(G[i]->getKey() == k) return G[i];
			return NULL;
		}

		void DFSVisit(NodeG<T>* s) {
			s->setColor(GREY);
			cout << "Visita del nodo " << s->getKey() << endl;
			int pos = getIndex(s->getKey());
			d[pos] = time++;
			cout << "Inizio visita di " << s->getKey() << " Ã¨ uguale a " << d[pos] << endl;

			Node< NodeG<T>* > *tmp = s->getAdj()->getHead();
			while( tmp!=NULL ) {
				NodeG<T> *node = tmp->getKey();
				if( node->getColor()==WHITE ) {
					p[getIndex(node->getKey())] = s;
					DFSVisit(node);
				}
				tmp = tmp->getNext();
			}

			f[pos] = time++;
			s->setColor(BLACK);
			cout << "Fine visita del nodo " << s->getKey() << endl;
			cout << "Fine visita di " << s->getKey() << " Ã¨ uguale a " << f[pos] << endl;
		}

		int getIndex(T key) {
			for(int i=0; i<n; i++)
				if( G[i]->getKey()==key ) return i;
			return -1;
		}
		
	public:
		Graph<T>(int n) {
			len = n;
			this->n = m = 0;
			G = new NodeG<T>*[len];
			for(int i=0; i<len; i++) G[i] = NULL;
		}
		Graph<T>* insertNode(T key) {
			if(n==len) return this;
			NodeG<T> *tmp = new NodeG<T>(key);
			G[n++] = tmp;
			return this;
		}
		
		
		Graph<T>* insertEdge(T k1, T k2) {
			NodeG<T> *node1 = search(k1);
			NodeG<T> *node2 = search(k2);
			if(!node1 || !node2) return this;
			node1->getAdj()->insert(node2);
			node2->incInDegree();
			m++;
			return this;
		}
		
		int hasEdge(T k1, T k2) {
			NodeG<T> *node1 = search(k1);
			NodeG<T> *node2 = search(k2);
			return node1->getAdj()->search(node2);
		}
		
		
		void DFS() {
			time = 0;
			d = new int[n];
			f = new int[n];
			p = new NodeG<T>*[n];
			for(int i=0; i<n; i++) {
				G[i]->setColor(WHITE);
				p[i] = NULL;
			}
			for(int i=0; i<n; i++)
				if( G[i]->getColor() == WHITE) {
					cout << "Inizia la visita del nodo " << G[i]->getKey() << endl;
					DFSVisit(G[i]);
				}
		}
		void BFS(T s) {}
};

int main() {
	Graph<int> *G = new Graph<int>(10);
	G->insertNode(4)->insertNode(3)->insertNode(1)->insertNode(5)->insertNode(2);
	G->insertEdge(4,3);
	G->insertEdge(3,2)->insertEdge(3,1);
	G->insertEdge(1,5)->insertEdge(1,4)->insertEdge(1,3);
	G->insertEdge(5,4)->insertEdge(5,1)->insertEdge(5,2);
	G->insertEdge(2,4);
	G->DFS();
	return 1;
}

*/
