#include <iostream>

using namespace std;

template <class N> class Nodo
{
   public:
       N key;
       Nodo<N>* next;
       
       Nodo<N>(N x)
       { 
          key=x;
          next=NULL;
       }
};

template <class T> class List
{
   public:
       virtual  List<T>*insert(T x)=0;
       virtual  int search(T x)=0;
       virtual  List<T>*del(T x)=0; 
};

template <class T> class LinkedList : public List<T>
{
    public:
        Nodo<T> * testa;
        int size;
 
        LinkedList<T>()
        {
           testa=NULL;
           size=0;
        }

        List<T>*insert(T x)
        {
           Nodo<T>* nuovo=new Nodo<T>(x);
           nuovo->next=testa;
           testa=nuovo;
           size++;
           return this;
        }  


        void print()
        {
           Nodo<T>*tmp=testa;
           while(tmp!=NULL)
           {
               cout<<tmp->key<<" / ";
               tmp=tmp->next;
           }
           cout<<endl;
        } 

        int search(T x)
        {
           if(size==0) return 0;
           Nodo<T>*temp=testa;
           while(temp!=NULL && temp->key!=x) temp=temp->next;

           if(temp!=NULL) return 1;
           else return 0;
        } 

        List<T>*del(T x)
        {
            if(size==0) return this;
            Nodo<T>*tmp=testa;
            Nodo<T>*prec=NULL;
            if(testa->key==x)
            {
               testa=testa->next;
               delete tmp;
               size--;
               return this;
            }

            while(tmp!=NULL && tmp->key!=x) 
            {
               prec=tmp;
               tmp=tmp->next;
            }

            if(tmp!=NULL)
            {
               prec->next=tmp->next;
               delete tmp;
               size--;
            }
            return this;

        }      
};


template <class H> class LGraph
{
    public:
         int len,n,m;
         H**k;
         LinkedList<int> ** adj;

         LGraph<H>(int len)
         {
            this->len=len;
            n=m=0;
            k=new H*[len];
            for(int i=0;i<len;i++) k[i]=NULL;
            adj=new LinkedList<int> *[len];
            for(int i=0;i<len;i++) adj[i]= new  LinkedList<int>();
         }

         int findIndex(H x)
         {
            for(int i=0;i<n;i++)
            {
               if(*k[i]==x) return i;
            }
            return -1;
         }

         LGraph<H> *addNode(H x)
         {
            if(len==n) return this;
            if(findIndex(x)>=0) return this;
            k[n]= new H(x);
            n++;
            return this;
         }

         LGraph<H> *addEdge(H x, H y)
         {
            int i=findIndex(x);
            int j=findIndex(y);
            if(i<0 || j<0) return this;
            if(adj[i]->search(j)==0)
            {
               adj[i]->insert(j);
               m++;
            } 
            return this;
         } 
  
         void print()
         {
            for(int i=0;i<n;i++)
            {
               cout<<"("<<i<<") "<<*k[i]<<" : ";
               adj[i]->print();
               cout<<endl;
            }
         }
         
};

int main()
{

    LGraph<int> *p = new LGraph<int>(9);
    p->addNode(0)->addNode(1)->addNode(2)->addNode(3);
    p->addNode(4)->addNode(5)->addNode(6)->addNode(7);
    p->addNode(8);

    p->addEdge(0,8)->addEdge(0,1);
    p->addEdge(1,8);
    p->addEdge(2,4);
    p->addEdge(3,5);
    p->addEdge(3,6);
    p->addEdge(3,7);
    p->addEdge(4,3);
    p->addEdge(4,0);
    p->addEdge(5,6);
    p->addEdge(5,3);
    p->addEdge(6,5);
    p->addEdge(8,2);
    p->print();
/*
    LinkedList<int> *p = new LinkedList<int>();
    p->insert(0)->insert(4)->insert(8)->insert(1)->insert(5)->insert(6)->insert(2);
    p->print();
    cout<<endl;
    cout<<"TROVATO 8? : "<<p->search(8)<<endl;
    cout<<"TROVATO 0? : "<<p->search(0)<<endl;
    cout<<"TROVATO 2? : "<<p->search(2)<<endl;
    cout<<"TROVATO 18? : "<<p->search(18)<<endl;
    p->del(8)->del(0)->del(2)->del(18);
    cout<<endl;
    cout<<"TROVATO 8? : "<<p->search(8)<<endl;
    cout<<"TROVATO 0? : "<<p->search(0)<<endl;
    cout<<"TROVATO 2? : "<<p->search(2)<<endl;
    cout<<"TROVATO 18? : "<<p->search(18)<<endl;
*/
}
