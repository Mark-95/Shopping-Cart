#include <iostream>

using namespace std;


template <class T> class Nodo
{
    public:
        T valore;
        int colore; 
        Nodo<T>* left;
        Nodo<T>* right;
	Nodo<T>* parent;
        Nodo<T>(T x)
        {
            valore=x;
            left=right=parent=NULL;
        }
 
};


template <class H> class Albero
{
    public:
       Nodo<H>* root;
       Albero<H>()
       {
          root=NULL;
       }

       Albero<H>* insert(H x)
       {
          Nodo<H>* nuovo= new Nodo<H>(x);
          Nodo<H>* temp=root;
          Nodo<H>* prec=NULL;
   
          while(temp!=NULL)
          {
              prec=temp;
              if(x>temp->valore) temp=temp->right;
              else temp=temp->left;
 
          }

          nuovo->parent=prec;
          if(prec==NULL) root=nuovo;
	  else if(x>prec->valore) prec->right=nuovo;
          else prec->left=nuovo;
          return this;
       }

       void  preorder_visit(Nodo<H>* n)
       {
           if(n!=NULL)
           {
               cout<<n->valore<<" / ";
               preorder_visit(n->left);
	       preorder_visit(n->right);
           }
       }

       void preorder()
       {
           preorder_visit(root);
           cout<<endl;
       } 


       Nodo<H>* search(H x)
       {
           Nodo<H>* temp=root;
           while(temp!=NULL && x!=temp->valore)
           {
              if(x>temp->valore) temp=temp->right;
              else temp=temp->left;
           }

           if(temp!=NULL)
           {
              cout<<"SEARCH: "<<temp->valore<<endl;
              return temp;
           }else return NULL;
       }

       Nodo<H>* minimo(Nodo<H>* n)
       {
          if(n==NULL) return n;
          Nodo<H> * temp=n;
          while(temp->left!=NULL) temp=temp->left;
          cout<<"MINIMO: "<<temp->valore<<endl;
          return temp; 
       } 
       
       Nodo<H>* massimo(Nodo<H>* n)
       {
          if(n==NULL) return n;
          Nodo<H> * temp=n;
          while(temp->right!=NULL) temp=temp->right;
          cout<<"MAX: "<<temp->valore<<endl;
          return temp; 
       }

       Nodo<H>* predecessore(Nodo<H>* n)
       {
          if(n==NULL) return NULL;
          cout<<"PREDECESSORE: "<<endl;
          if(n->left!=NULL) return massimo(n->left);
          Nodo<H>* temp=n->parent;
          while(temp!=NULL && n==temp->left)
          {
             n=temp;
             temp=temp->parent;
          } 

          return temp; 
       }

       Nodo<H>* successore(Nodo<H>* n)
       {
          if(n==NULL) return NULL;
          cout<<"SUCCESSORE: "<<endl;
          if(n->right!=NULL) return minimo(n->right);
          Nodo<H>* temp=n->parent;
          while(temp!=NULL && n==temp->right)
          {
             n=temp;
             temp=temp->parent;
          } 

          return temp; 
       }

       Albero<H>* rightrotate(H key)
       {
          Nodo<H>* y=search(key);
          if(y==NULL) return y;
          Nodo<H>* x=y->left;
          Nodo<H>* z=y->parent;
          y->left=x->right;
          x->right=y;
          if(z!=NULL)
          {
              if(y==z->right) z->right=x;
              else z->left=x;
          }else root=x;
          x->parent=z;
          y->parent=x;
          if(y->left!=NULL) y->left->parent=y;
          return this;
       } 

       Albero<H>* leftrotate(H key)
       {
          Nodo<H>* y=search(key);
          if(y==NULL) return y;
          Nodo<H>* x=y->right;
          Nodo<H>* z=y->parent;
          y->right=x->left;
          x->left=y;
          if(z!=NULL)
          {
              if(y==z->right) z->right=x;
              else z->left=x;
          }else root=x;
	  x->parent=z;
          y->parent=x;
          if(y->right!=NULL) y->right->parent=y;
          return this;
       } 

       Nodo<H>*delete_nodo(H x)
       {
          Nodo<H>* n=search(x);
          if(n==NULL) return n;
          Nodo<H>* p=n->parent;
          if(n->left==NULL) 
          {
             if(p)
             {
               if(n==p->left) p->left=n->right;
               else p->right=n->right; 
             }else root=n->right;
             return n;
          }

         if(n->right==NULL) 
          {
             if(p)
             {
               if(n==p->left) p->left=n->left;
               else p->right=n->left; 
             }else root=n->left;
             return n;
          }

          Nodo<H>* s=successore(n);
          del(s->valore);
          n->valore=s->valore;
          return s;

       }

       Albero<H>* del(H x)
       {
          
          delete_nodo(x);
          return this;
          
       }

};

int main()
{
   Albero<int>* p=new Albero<int>();
   p->insert(25)->insert(30)->insert(15)->insert(60)->insert(24)->insert(1);
   p->preorder();
   p->del(30);
   p->preorder();
   cout<<endl;
   p->del(15);
   p->preorder();
}
