#include <iostream>
using namespace std;

template <class T> class Nodo
{
   public:
      T valore;
      int color;
      Nodo<T>*left;
      Nodo<T>*right;
      Nodo<T>*parent;
      Nodo<T>(T x)
      {
         valore=x;
         left=right=parent=NULL;
      }
};

template <class H> class RBtree
{
    public:
        Nodo<H>*root;
        RBtree<H>()
        {
           root=NULL;
        }

        RBtree<H>* insert(H x)
        {
            Nodo<H>*nuovo= new Nodo<H>(x);
            Nodo<H>* temp=root;
            Nodo<H>*prec=NULL;
            
            while(temp!=NULL)
            {
                prec=temp;
                if(x>temp->valore) temp=temp->right;
                else temp=temp->left;
            } 

            nuovo->parent=prec;
            if(prec==NULL) root=nuovo;
            else if(x>prec->valore) prec->right=nuovo;
            else prec->left=nuovo;
            nuovo->color=1;  //1=RED
            RBInsertFixup(nuovo);
            return this;
        } 

        void preorder(Nodo<H>*temp)
        {
           if(temp!=NULL)
           {
              if(temp->color==0) cout<<"["<<temp->valore<<", B]"<<" / ";
	      else if(temp->color==1) cout<<"["<<temp->valore<<", R]"<<" / ";
              preorder(temp->left);
	      preorder(temp->right); 
           }
        }

        void print()
        {
           
           preorder(root);
           cout<<endl; 
        }  


        Nodo<H>*search(H x)
        {
           Nodo<H>* temp=root;
           while(temp!=NULL && x!=temp->valore)
           {
                if(x>temp->valore) temp=temp->right;
                else temp=temp->left;
           }
           
           if(temp!=NULL)
           {
              cout<<"SEARCH: "<<temp->valore<<endl;
	      return temp;	
           } 
           else
           {
	      cout<<"SEARCH NULL"<<endl;	
              return NULL;  
           }
        }

        RBtree<H>* rightrotate(H key)
        {
            Nodo<H>* y=search(key);
            if(y==NULL) return this;
            Nodo<H>* x= y->left;
            Nodo<H>* z= y->parent;
            y->left=x->right;
            x->right=y;
            if(z!=NULL)
            {
                if(y==z->right) z->right=x;
                else z->left=x;
            }else root=x;
            x->parent=z;
	    y->parent=x; 
            if(y->right!=NULL) y->right->parent=y;
            return this;
        }

        RBtree<H>* leftrotate(H key)
        {
            Nodo<H>* y=search(key);
            if(y==NULL) return this;
            Nodo<H>* x= y->right;
            Nodo<H>* z= y->parent;
            y->right=x->left;
            x->left=y;
            if(z!=NULL)
            {
                if(y==z->right) z->right=x;
                else z->left=x;
            }else root=x;
            x->parent=z;
	    y->parent=x; 
            if(y->left!=NULL) y->left->parent=y;
            return this;
        } 

        void RBInsertFixup(Nodo<H>*z)
        {
           if(z->parent!=NULL && z->parent->color==0) return ;
           if(z==root)
           {
              z->color=0;   //0=BLACK
              return;
           }
           Nodo<H>*padre= z->parent;
           Nodo<H>*nonno= padre->parent;
           Nodo<H>*zio;
           if(nonno->right==padre) zio=nonno->left;
           else zio=nonno->right;
           if(zio!=NULL && zio->color==1)
           {
              zio->color=0;
              padre->color=0;
              nonno->color=1;
              RBInsertFixup(nonno);
              return;
           }

           if(padre==nonno->left)
           {
               if(z==padre->right)
               {
                  this->leftrotate(padre->valore);
                  padre=z;
                  z=padre->left;
               } 
               this->rightrotate(nonno->valore);
               nonno->color=1;
               padre->color=0;               
               
               return;
           }else
           {
               if(z==padre->left)
               {
                  this->rightrotate(padre->valore);
                  padre=z;
                  z=padre->right;
               }
               this->leftrotate(nonno->valore);
               padre->color=0;
               nonno->color=1;
               return;
           }

        }

         

};


int main()
{
   RBtree<int> *p= new RBtree<int>();
   p->insert(25)->insert(0)->insert(12)->insert(30)->insert(2)->insert(15);
   p->print();
}
