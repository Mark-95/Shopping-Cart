
#include<iostream>
 
using namespace std;
 
int main()
{
    int m=2;  //riga1
    int n=2;  //colonna1

    int p=2;  //riga2
    int q=2;  //colonna2

    int c[m][q];  //array risultato

    //matrice1
    int a[m][n]=
    {
	    {2, 4},
	    {8, 3}
    };
   
    //matrice2
    int b[p][q]=
    {
	    {3, 2},
	    {5, 0}
    };

    if(n==p)
    {
        cout<<"PRODOTTO: "<<endl;
        for(int i=0;i<m;++i)
        {
            for(int j=0;j<q;++j)
            {
                c[i][j]=0;
                for(int k=0;k<n;++k)
                    c[i][j]=c[i][j]+(a[i][k]*b[k][j]);
                cout<<c[i][j]<<" ";
        }
            cout<<"\n";
        }
    }
    else
        cout<<"Non è possibile eseguire il prodotto"<<endl;
 
}
