#include <iostream>

using namespace std;


int matrix_chain_order(int *p, int n)
{
   int m[n][n];
   int s[n][n];

   int i,j,q,k;

   int min=0;
   int minimo=0;
   int size=n-1;

   for(i=1;i<n;i++) m[i][i]=0;

   for(i=2;i<=size; i++)
   {
      for(j=1; j<=size-i+1;j++) 
      {
         k=i+j-1;
         m[j][k]=1000000000;
         for(q=j;q<=k-1;q++)
         {
            min=m[j][q]+m[q+1][k]+p[j-1]*p[k]*p[q];
            if(min<m[j][k])
            {
               m[j][k]=min;
               minimo=min;
               s[j][k]=q;
            }
         }
      }
   }

   return minimo;
}

int main()
{
   int n=7;
   int p[]={30,35,15,5,10,20,25};
   cout<<"NUMERO MINIMO DI MOLTIPLICAZIONI: "<<matrix_chain_order(p,n)<<endl;
}
