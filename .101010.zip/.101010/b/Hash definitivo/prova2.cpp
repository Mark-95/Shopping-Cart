#include<iostream>
#include<ctime>
#include<math.h>
#include "prova 1.cpp"
using namespace std;

template <class T> class HashTable{
	public:
		virtual HashTable<T>* insert(T x)=0;
		virtual int search(T x)=0;
		virtual HashTable<T>* del(T x)=0;
};

template <class H> class LinkedHashTable: public HashTable<H>{      //LinkedHashTable  (sottoclasse),    HashTable (superclasse)
	public:
		virtual int hash(H x)=0;         //Definizione prototipo del metodo hash() che sarà implementato nella sottoclasse
		int m;
		int size;
		LinkedList<H> **t;
		
		LinkedHashTable<H>(int m){
			t=new LinkedList<H>*[m];
			for(int i=0;i<m;i++) t[i]= new LinkedList<H>();       //LinkedList  (lista definita in prova1.cpp)
			size=0;
			this->m=m;
		}
		
		LinkedHashTable<H>* insert(H x){   
			int p=hash(x);            //Determino la posizione in cui il valore 'x' sarà inserito nella tabella
			t[p]->insert(x);          //accedo a tale posizione in cui sarà presente un puntatore al metodo INSERT della classe LinkedList che si trova nel file prova1.cpp
			size++;			  
			return this;
		}
		
		int search(H x){
			int p=hash(x);            //Determino la posizione del valore 'x' nella tabella
			return t[p]->search(x);   //accedo a tale posizione in cui sarà presente un puntatore al metodo SEARCH della classe LinkedList che si trova nel file prova1.cpp
		}
		
		LinkedHashTable<H>* del(H x){
			int p=hash(x);		  //Determino la posizione del valore 'x' nella tabella
			if(t[p]->search(x)){      //accedo a tale posizione in cui sarà presente un puntatore al metodo SEARCH della classe LinkedList che si trova nel file prova1.cpp
				t[p]->del(x);     //Se il valore si trova effettivamente in quella posizione allora punta al metodo DEL della classe LinkedList per cancellarlo.
				size--;
			}
			return this;
		}
		
		void print(){
			for(int i=0;i<m;i++){           //scorro la tabella hash dove per ogni cassetto vi è un puntatore al metodo PRINT della classe LinkedList che si trova nel file prova1.cpp  
				cout<<"["<<i<<"] ->";    
				t[i]->print();          //e quindi per ogni posizione della tabella hash stampo la lista o il valore contenuto dentro.
				cout<<endl;
			}
			cout<<endl;
		}
};

template <class H> class DivLinkedHashTable: public LinkedHashTable<H>{        //DivLinkedHashTable  (sottoclasse),    LinkedHashTable (superclasse)
	public:
		int hash(H x){                           //Determino la posizione del valore 'x' mediante hash con divisione.
			int p=((int) x%this->m);
			return p;
		}
		
		DivLinkedHashTable(int m): LinkedHashTable<H>(m){}    //Costruttore della sottoclasse DivLinkedHashTable  eredita tutto dall costruttore della superclasse LinkedHashTable
};

template <class H> class MulLinkedHashTable: public LinkedHashTable<H>{       //MulLinkedHashTable  (sottoclasse),    LinkedHashTable (superclasse)
	public:
		double c;
		int hash(H x){                           //Determino la posizione del valore 'x' mediante hash con moltiplicazione e costante moltiplicativa c=0.7.
			double y=(int)x*c;               //moltiplico la parte intera del valore in input 'x' per la costante 'c' 
			double a=y-int(y);               // al risultato tolgo la parte intera poichè la formula prevede modulo 1
			int p=a*this->m;                 // moltiplico la parte decimale rimanente per la dimensione dell'hash 'm'.
			return p;
		}
		
		MulLinkedHashTable(int m):LinkedHashTable<H>(m){     //Costruttore della sottoclasse MulLinkedHashTable  eredita tutto dall costruttore della superclasse LinkedHashTable
			c=0.7;
		}
};

template <class H> class OpenHashTable: public HashTable<H>{         //OpenHashTable  (sottoclasse),    HashTable (superclasse)
	public:
		virtual int hash(H x, int i)=0;			     //Definizione prototipo del metodo hash() che sarà implementato nella sottoclasse
		int m;                                               //Dimensione tabella hash
		int size;
		H** t;
		H* deleted;
		
		OpenHashTable<H>(int m){ 
			this->m=m;                                 //Inizializzo il valore 'this->m' (cioè la dimensione della tabella hash definita nella classe) con il parametro 'm' passato al costruttore.
			size=0;                                    //Numero elementi inseriti
			t=new H*[m];
			for(int i=0;i<m;i++) t[i]=NULL;
			deleted=new H();                           //Alloco puntatore 
		}
		
		OpenHashTable<H>* insert(H x){                     
			if(size==m) return this;                     //Se la tabella hash è piena non inserisco
			int i=0;
			int p=hash(x,i);                             //Se invece non è piena determino la posizione del valore 'x'
			while(i<m && t[p]!=NULL && t[p]!=deleted){   //Ripeto fino a quando la tabella non termina && fino a quando il cassetto è pieno && nel cassetto non è stato cancellato il valore
				i++;
				p=hash(x,i);                          //Se le condizioni sono tutte soddisfatte allora ricalcolo la nuova posizione di 'x' poichè il posto appena controllato era già occupato.
			}
			if(t[p]==NULL|| t[p]==deleted) t[p]=new H(x);  //Se trovo un cassetto vuoto || il cassetto era pieno ma il suol valore è stato cancellato allora inserisco il nuovo valore.
			return this;
		}
		
		int search(H x){                                       
			int i=0;
			int p=hash(x,i);                                 //Determino la posizione in cui è presente 'x' nella tabella
			while(i<m && t[p]!=NULL){                        //Ripeto il ciclo fino a quando il corrente cassetto è < della dimensione della tabella && il cassetto è pieno
				if(t[p]!=deleted && *t[p]==x) return 1;  //Se il cassetto non è stato cancellato && il valore del cassetto è 'x'  allora restituisco 1.
				i++;                                     //Altrimenti ripeto la ricerca
				p=hash(x,i);                             //e calcolo la nuova posizione
			}
			return 0;                                        //Se alla fine non lo trovo restituisco 0.
		}
		
		OpenHashTable<H>* del(H x){
			int i=0;
			int p=hash(x,i); 				  //Determino la posizione in cui è presente 'x' nella tabella	
			while(i<m && t[p]!=NULL){                         //scorro fino a quando non termino la tabella && il cassetto visitato è pieno, ricalcolando la posizione del valore 'x'
				if(*t[p]==x){                             //Ma se trovo il valore in un cassetto allora attrverso il puntatore 'deleted' segno il cassetto come cancellato e interrompo il ciclo.
					t[p]=deleted;
					return this;
				}
				i++;
				p=hash(x,i);
			}
			return this;
		}
		
		void print(){
			for(int i=0;i<m;i++){                                             //Scorro la tabella e se il cassetto corrente è pieno && non è stato cancellato allora stampo.
				if(t[i] && t[i]!=deleted) cout<<"["<<i<<"] ->"<<*t[i];
				else cout<<"["<<i<<"] -> //";
				cout<<endl;
			}
			cout<<endl;
		}
};

template <class H> class LinearOpenHashTable: public OpenHashTable<H>{                //LinearOpenHashTable  (sottoclasse),    OpenHashTable (superclasse)
	public:
			int hash(H x, int i){					      //Calcolo la posizione di 'x' attraverso la formula del hash lineare ad indirizzamento aperto
										
			int a=(((int) x%this->m)+i)%this->m;                          // (k+i) mod m                       
			return a; 
		}
		
		LinearOpenHashTable(int m): OpenHashTable<H>(m){}		      //Costruttore della sottoclasse LinearOpenHashTable  eredita tutto dall costruttore della superclasse OpenHashTable
};

int main(){
	cout<<"LISTA CONCATENATA CON FUNZIONE MOLTIPLICATIVA"<<endl;
	MulLinkedHashTable<int> *A=new MulLinkedHashTable<int>(5);
	A->insert(4)->insert(1)->insert(10)->insert(25)->insert(15);
	A->print();
	cout<<endl<<"TABELLA APERTA CON FUNZIONE LINEARE"<<endl;
	
	LinearOpenHashTable<int> *T1= new LinearOpenHashTable<int>(11);
	T1->insert(4)->insert(34)->insert(31)->insert(56)->insert(51)->insert(44)->insert(33)->insert(77)->insert(50);
	T1->del(34)->del(77);
	T1->insert(77)->insert(22);
	T1->print();
	cout<<endl<<"LISTA CONCATENA CON FUNZIONE DI DIVISIONE"<<endl;
	
	DivLinkedHashTable<int> *B=new DivLinkedHashTable<int>(5);
	B->insert(4)->insert(1)->insert(10)->insert(25)->insert(15);
	B->print();
	
	
}
