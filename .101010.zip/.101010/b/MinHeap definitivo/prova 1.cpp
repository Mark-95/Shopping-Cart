#include<iostream>
#include<math.h>
#include<ctime>
using namespace std;

template <class T> class BHeap{
	public:
		virtual BHeap<T>* enqueue(T x)=0;
		virtual T* top()=0;
		virtual BHeap<T>* extract()=0;
		virtual BHeap<T>* buildHeap(T* v, int n)=0;
		virtual void print()=0;
};

template <class H> class MinHeap: public BHeap<H>{
	private:
		H** A;
		int heapsize;
		int len;
		int right(int i){ return i<<1|1;}
		int left(int i){ return i<<1;}
		int parent(int i){ return i>>1;}
		
		void scambia(int i, int j){
			H* temp=A[i];
			A[i]=A[j];
			A[j]=temp;
		}
		
		void heapify(int i){
			if(i>heapsize) return ;
			int l=left(i);
			int r=right(i);
			int min=i;
			if(l<=heapsize && compare(A[min],A[l])>0) min=l;
			if(r<=heapsize && compare(A[min],A[r])>0) min=r;
			if(min==i) return;
			scambia(i,min);
			heapify(min);
		}
	public:	

		int compare(H* a, H* b){
			return (*a)-(*b);
		}
		
		MinHeap<H>(int size){
			A=new H*[size];
			len=size;
			heapsize=0;
		}
		
		BHeap<H>* enqueue(H x){
			heapsize++;
			A[heapsize]=new H(x);
			int i=heapsize;
			while(i>1 && compare(A[parent(i)],A[i])>0){
				scambia(parent(i),i);
				i=parent(i);
			}
			return this;
		}
		
		H* top(){
			if(heapsize==0) return NULL;
			return A[1];
		}
		
		BHeap<H>* extract(){
			if(heapsize==0) return NULL;
			scambia(1,heapsize);
			heapsize--;
			heapify(1);
			return this;
		}
		
		BHeap<H>* buildHeap(H* v, int n){
			for(int i=0;i<n;i++){
				heapsize++;
				A[heapsize]=new H(v[i]);
			}
			for(int i=n/2;i>=1;i--)
				heapify(i);
			return this;
		}
		
		void print(){
			for(int i=1;i<=heapsize;i++)
				cout<<*A[i]<<" ";
			cout<<endl;
		}
};


int main(){
	int n=9;
	int v[]={5,3,2,8,6,1,13,4,14};
	MinHeap<int> *M=new MinHeap<int>(100);
	M->buildHeap(v,n);
	M->enqueue(7)->enqueue(10)->enqueue(12);
	M->extract();
	M->extract();
	M->print();
	return 1;
}
