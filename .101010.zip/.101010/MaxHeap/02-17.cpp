#include <iostream>

using namespace std;


template<class H> class BHeap
{
   public:
	virtual BHeap<H> * enqueue(H x)=0;
        virtual H *top() =0;
        virtual BHeap<H> * extract() =0;
	virtual BHeap<H> * buildHeap(H*v , int n) =0;
        virtual void print()=0;
};

template<class H> class MaxHeap : public BHeap<H>
{
    private:
         H **A;
         int heapsize,len;
         int left(int i){ return i<<1; }
         int right(int i){ return i<<1|1; }
         int parent(int i){ return i>>1; }
     
         void scambia(int i,int j) 
	 {
            H *tmp= A[i];
            A[i]=A[j];
            A[j]= tmp;
	 }

         void heapify(int i)
         {
            int l=left(i);
            int r=right(i);
            int max=i;
            
            if(l<=heapsize && compare(A[max],A[l])<0) max=l;
 	    if(r<=heapsize && compare(A[max],A[r])<0) max=r;
            if(max!=i)
            {
              scambia(i,max);
              heapify(max); 
            }else return;            
	 }

     public:
         int compare(H *a, H*b)
         {
            return (*a)-(*b);  
         }

         MaxHeap(int size)
	 {
            heapsize=0;
	    len=size;
            A= new H*[size];  
	 }
         
         BHeap<H> * enqueue(H x)
	 {
            if(heapsize<len)
	    {
		heapsize++;
                A[heapsize] = new H(x);
		int i=heapsize;
 
                while(i>1 && compare(A[parent(i)],A[i])<0)
                {
                   scambia(parent(i),i);
                   i=parent(i); 
		}
	    }
            return this;
	 }  

         H *top()
         {
	 } 
         BHeap<H> * extract()
	 {
            if(heapsize<=0)return NULL;
            else
	    {
		scambia(heapsize,1);
                heapsize--;
                heapify(1);
                return this; 
            }
            
	 }

	 BHeap<H> * buildHeap(H*v , int n)
	 {
            for(int i=0;i<n;i++)
            {
                heapsize++;
	        A[heapsize]= new H(v[i]);
	    }
            for(int i=n/2; i>=1; i--)
	    {
		heapify(i);	
            }
            return this; 
	 }


         void print()
         {
             for(int i=1;i<=heapsize;i++)
	     {
                 cout<<*A[i]<<" / ";
		 
             }	
             cout<<endl;
	 }
};

int main()
{
    int n=9;
    int v[]={5,3,2,8,6,1,13,4,14};
    MaxHeap<int> *p = new MaxHeap<int>(100);
    p->buildHeap(v,n);
    p->enqueue(7)->enqueue(10)->enqueue(12);

    p->extract();
    p->extract();
p->print();
    
    
    return 1;
}
