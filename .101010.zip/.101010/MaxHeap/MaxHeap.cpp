#include <iostream>

using namespace std;

template <class T> class BHeap
{
    public:
       virtual BHeap<T> * enqueue(T x)=0;
       virtual BHeap<T> * extract()=0;
       virtual T* top()=0;
       virtual BHeap<T> *buildHeap(T *v, int n)=0;
       virtual void print()=0;

};

template <class H> class MaxHeap : public BHeap<H>
{
    private:
	H** A;
        int heapsize;
        int len;  
        int left(int i){ return i<<1; }
        int right(int i){ return (i<<1)|1; }
        int parent(int i){ return i>>1; }
        
	void scambia(int i, int j)
	{
	   H*tmp = A[i];
           A[i]=A[j];
	   A[j]=tmp;
	}

        void heapify(int i)
        {
           if(i>heapsize) return;
           int l=left(i);
           int r=right(i);
           int m=i;
           
           if(l<=heapsize && compare(A[l],A[m])>0) m=l;
           if(r<=heapsize && compare(A[r],A[m])>0) m=r;
           if(i==m) return;
           scambia(i,m);
           heapify(m);
        }
  
    public:
        H compare(H*a, H*b){ return (*a)-(*b); }
        MaxHeap<H>(H size)
        {
           heapsize=0;
           len=size;
           A= new H*[size]; 
        }

        BHeap<H>* buildHeap(H *v, H n)
	{
	   for(int i=0;i<n;i++)
           {
              heapsize++;
              A[heapsize] = new H(v[i]);
           }
    
           for(int i=heapsize/2; i>=1; i--) heapify(i);  
           return this;
	}

        void print()
        {
           for(int i=1;i<=heapsize;i++)
           {
               cout<<*A[i]<<" ";
           }
           cout<<endl;
        }

        H* top()
        { 
           if(heapsize==0) return NULL; 
           return A[1]; 
        }

        BHeap<H> * enqueue(H x)
        {
	   if(heapsize==len-1) return this;
           heapsize++;
           A[heapsize]= new H(x);
           int i=heapsize;
           while(i>1 && compare(A[parent(i)],A[i]) <0)
           {
              scambia(parent(i),i);
              i=parent(i);
           }
           return this;
 	}

	BHeap<H> * extract()
        {
           if(heapsize==0) return this;
           scambia(1,heapsize);
           heapsize--;
           heapify(1);
           return this;
	}

        void modify(int i, H k)
        {
           if(i<1 || i>heapsize) return;
           if(compare(A[i],&k) >0) return;
           A[i] = new H(k);

           while(i>1 && compare(A[parent(i)],A[i]) <0)
	   {
               scambia(parent(i),i);
               i=parent(i);
           }
           
	} 

        void sort()
        {
           int n=heapsize;
           for(int i=1; i<=n ;i++) extract();
           heapsize=n;
        }

};

int main()
{
   int n=9;
   int v[]={5,3,2,8,6,1,13,4,14};

   MaxHeap<int> *p = new MaxHeap<int>(100);
   p->buildHeap(v,n);
   p->print();
   cout<<endl;
   cout<<"Radice: "<<*p->top()<<endl;
   cout<<endl;
   p->enqueue(7)->enqueue(10)->enqueue(12);
   p->print();
   p->extract()->extract();
   p->print();
   cout<<"modify"<<endl;
   p->modify(2,15);
   p->print();
   cout<<endl<<"sort"<<endl;
   p->sort();
   p->print();

   return 0;
}
