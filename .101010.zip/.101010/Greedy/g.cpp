
#include <bits/stdc++.h>
using namespace std;



/*
void quickSort(Activitiy arr[], int left, int right) {

      int i = left, j = right;

      Activitiy tmp;

      Activitiy pivot = arr[(left + right) / 2];

 

      // partition 

      while (i <= j) {

            while (arr[i].finish < pivot.finish)

                  i++;

            while (arr[j].finish > pivot.finish)

                  j--;

            if (i <= j) {

                  tmp = arr[i];

                  arr[i] = arr[j];

                  arr[j] = tmp;

                  i++;

                  j--;

            }

      };

 

      // recursion 

      if (left < j)

            quickSort(arr, left, j);

      if (i < right)

            quickSort(arr, i, right);

}
*/

struct Activitiy
{
	int start, finish;
};


bool activityCompare(Activitiy s1, Activitiy s2)
{
	return (s1.finish < s2.finish);
}


void printMaxActivities(Activitiy arr[], int n)
{
	
	sort(arr, arr+n, activityCompare);
        //quickSort(arr,0,n);

	// The first activity always gets selected
	int i = 0;
	cout <<"Activity: "<< i <<"= (" << arr[i].start << ", "<< arr[i].finish << ") "<<endl;

	// Consider rest of the activities
	for (int j = 1; j < n; j++)
	{

		if (arr[i].finish <= arr[j].start )
		{
			cout <<"Activity: "<< j <<"= (" << arr[j].start << ", "<< arr[j].finish << ") "<<endl;
			i = j;
		}
	}
}


int main()
{
	Activitiy arr[] = {{5, 9}, {1, 2}, {3, 4}, {0, 6},{5, 7}, {8, 9}};
	int n = sizeof(arr)/sizeof(arr[0]);  //6
	printMaxActivities(arr, n);
        cout<<endl;
	return 0;
}


